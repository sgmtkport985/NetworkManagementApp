﻿using NetworkManagementApp.Models;
using NetworkManagementApp.ViewModels;
using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;

namespace NetworkManagementApp.Views
{
    /// <summary>
    /// VendorInfoRegisterWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class VendorInfoRegisterWindow : Window
    {
        #region 「閉じるボタン」を非表示にする処理

        /// <summary>
        /// メニューのハンドル取得
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="bRevert"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        /// <summary>
        /// メニュー項目の削除
        /// </summary>
        /// <param name="hMenu"></param>
        /// <param name="uPosition"></param>
        /// <param name="uFlags"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        private static extern bool RemoveMenu(IntPtr hMenu, uint uPosition, uint uFlags);

        /// <summary>
        /// ウィンドウを閉じる
        /// </summary>
        private const int SC_CLOSE = 0xf060;

        /// <summary>
        /// uPositionに設定するのは項目のID
        /// </summary>
        private const int MF_BYCOMMAND = 0x0000;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_SourceInitialized(object sender, EventArgs e)
        {
            IntPtr hwnd = new System.Windows.Interop.WindowInteropHelper((Window)sender).Handle;
            IntPtr hMenu = GetSystemMenu(hwnd, false);
            RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
        }

        #endregion

        public VendorInfoRegisterViewModel vendorInfoRegisterViewModel { get; set; }

        public VendorInfoRegisterWindow(MainWindow mainWindow)
        {
            InitializeComponent();
            vendorInfoRegisterViewModel = new VendorInfoRegisterViewModel(mainWindow, this);
            DataContext = vendorInfoRegisterViewModel;
        }

        public VendorInfoRegisterWindow(bool isUpdate, MainWindow mainWindow, VendorInfoTable selectedVendorInfoTable)
        {
            InitializeComponent();
            vendorInfoRegisterViewModel = new VendorInfoRegisterViewModel(selectedVendorInfoTable, mainWindow, this);
            DataContext = vendorInfoRegisterViewModel;

            if (isUpdate)
            {
                Title = "ベンダー情報更新画面";
                Button.Content = "ベンダー情報更新";

                VendorCodeTextbox.IsReadOnly = true;
            }
        }
    }
}
