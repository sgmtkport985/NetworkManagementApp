﻿using NetworkManagementApp.MVVM;
using NetworkManagementApp.Views;

namespace NetworkManagementApp.ViewModels.Util
{
    public abstract class Base_InfoRegisterViewModel: NotifyPropertyChanged
    {
        protected MainWindow mainWindow { get; set; }

        public RelayCommand ToMainViewWinodow { get; set; }
        public RelayCommand ToInfoWinodow { get; set; }
        public RelayCommand InfoRegister { get; set; }

        protected string text_Info = "";
        protected string text = "";
        protected string nowString = "";

        private string _RemarksTextBox;
        public virtual string RemarksTextBox
        {
            get { return _RemarksTextBox; }
            set { _RemarksTextBox = value; OnPropertyChanged(RemarksTextBox); }
        }

        protected Base_InfoRegisterViewModel()
        {
            InfoRegister = new RelayCommand(InfoRegisterExecute, CanExecute);
            ToMainViewWinodow = new RelayCommand(ToMainViewWinodowExecute, CanExecute);
            ToInfoWinodow = new RelayCommand(ToInfoWinodowExecute, CanExecute);
        }

        public virtual bool CanExecute(object sender)
        {
            return true;
        }
        public abstract void ToMainViewWinodowExecute(object sender);
        public abstract void ToInfoWinodowExecute(object sender);
        public abstract void InfoRegisterExecute(object sender);
        public abstract void InfoUpdateExecute(object sender);

        protected abstract string getRegisterTextInfo(string nowString);
        protected abstract string getUpdateTextInfo(string nowString);
        protected abstract void setCollectionClear();
        protected abstract void RegisterValidationCheck();
        protected abstract void UpdateValidationCheck();

    }
}
