﻿
using System.Windows;
using NetworkManagementApp.MVVM;
using NetworkManagementApp.Views;

namespace NetworkManagementApp.ViewModels.Util
{
    public abstract class Base_InfoViewModel : NotifyPropertyChanged,IInfoExecute
    {
        protected MainWindow mainWindow { get; set; }

        public RelayCommand ShowInfoRegisterWindow { get; set; }
        public RelayCommand ShowBulkRegisterWindow { get; set; }
        public RelayCommand UpdateCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }
        public RelayCommand AllDeleteCommand { get; set; }
        public RelayCommand ToMainViewWinodow { get; set; }
        public RelayCommand OutputAllDataCommand { get; set; }

        private string _InfoTablesCount;
        public virtual string InfoTablesCount
        {
            get { return _InfoTablesCount; }
            set
            {
                _InfoTablesCount = value;
                OnPropertyChanged(nameof(InfoTablesCount));
            }
        }

        protected string sqlDeleteFromCommand { get; set; }

        public Base_InfoViewModel()
        {
            initProperty();
            SetTables();

            ToMainViewWinodow = new RelayCommand(ToMainViewWinodowExecute, CanExecute);
            ShowInfoRegisterWindow = new RelayCommand(ShowInfoRegisterWindowExecute, CanExecute);
            ShowBulkRegisterWindow = new RelayCommand(ShowBulkRegisterWindowExecute, CanExecute);

            UpdateCommand = new RelayCommand(UpdateCommandExecute, CanExecute);
            DeleteCommand = new RelayCommand(DeleteCommandExecute, CanExecute);
            AllDeleteCommand = new RelayCommand(AllDeleteCommandExecute, CanExecute);
            OutputAllDataCommand = new RelayCommand(OutputAllDataCommandExecute, CanExecute);
        }

        protected virtual void initProperty()
        {
        }

        public virtual void AllDeleteCommandExecute(object sender)
        {
            MessageBoxResult result = MessageBox.Show("すべての登録情報を削除します。\n\nよろしいですか？", "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                //SQL sQL = SQL.GetInstance();
                //string sqlDeleteFromCommand = "DELETE FROM 機器情報;";
                //sQL.CommandExecute(sqlDeleteFromCommand);
                ClearTables();
                SetTablesCount();
                MessageBox.Show("すべての登録情報を削除しました。");
            }
        }
        public virtual bool CanExecute(object sender)
        {
            return true;
        }
        public abstract void DeleteCommandExecute(object sender);
        public abstract void ShowBulkRegisterWindowExecute(object sender);
        public abstract void ShowInfoRegisterWindowExecute(object sender);
        public abstract void ToMainViewWinodowExecute(object sender);
        public abstract void UpdateCommandExecute(object sender);
        public abstract void OutputAllDataCommandExecute(object sender);

        protected abstract void BulkRegisterValidationCheck();
        protected abstract void SetTables();
        protected abstract void ClearTables(); 
        protected abstract void SetTablesCount();
    }
}
