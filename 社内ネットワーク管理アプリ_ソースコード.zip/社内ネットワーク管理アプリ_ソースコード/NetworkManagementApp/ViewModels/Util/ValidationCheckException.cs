﻿using System;

namespace NetworkManagementApp.ViewModels.Util
{

    [Serializable()] 
    public class ValidationCheckException : Exception
    {
        public ValidationCheckException(string message): base(message)
        {
        }
    }
}
