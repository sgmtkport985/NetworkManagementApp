﻿using NetworkManagementApp.Models;
using System;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Windows;


namespace NetworkManagementApp.ViewModels.Util
{
    public class WebApiClient
    {
        // ローカル用
        //private static readonly string URL = "https://localhost:7080/api";

        // 本番用（ダミー化しています）
        private static readonly string URL = "https://hogehoge.net/api";

        private static HttpResponseMessage Response { get; set; } = new HttpResponseMessage();

        private static string TimeoutMessage { get; set; } = "処理がタイムアウトしました。";
        private static string ClientErrorMessage { get; set; } = "Apiへクエリを送信できませんでした。";

        private static readonly HttpClient client = new HttpClient();

        public enum EnumViewModel { Place, Vendor, Equipment, IpMonitor, MacMonitor , MainMonitor }

        #region READ GEGION

        
        public static async void ReadTableData(EnumViewModel infoViewModel)
        {
            try
            {
                if (infoViewModel == EnumViewModel.IpMonitor)
                {
                    var Data = await client.GetFromJsonAsync<ObservableCollection<IpMonitorInfoTable>>($"{URL}/IpMonitorInfoTables");
                    if (Data != null)
                    {
                        IpMonitorInfoViewModel.InfoTables.Clear();
                        foreach (var item in Data)
                        {
                            IpMonitorInfoViewModel.InfoTables.Add(new IpMonitorInfoTable(item.IpMonitorInfoId, item.IPAddress, item.RegisterDateTime, item.UpdateDateTime, item.Remarks));
                        }
                    }
                }
                else if (infoViewModel == EnumViewModel.MacMonitor)
                {
                    var Data = await client.GetFromJsonAsync<ObservableCollection<MacMonitorInfoTable>>($"{URL}/MacMonitorInfoTables");
                    if (Data != null)
                    {
                        MacMonitorInfoViewModel.InfoTables.Clear();
                        foreach (var item in Data)
                        {
                            MacMonitorInfoViewModel.InfoTables.Add(new MacMonitorInfoTable(item.MacMonitorInfoId, item.MACAddress, item.RegisterDateTime, item.UpdateDateTime, item.Remarks));
                        }
                    }
                }
                else if (infoViewModel == EnumViewModel.Place)
                {
                    var Data = await client.GetFromJsonAsync<ObservableCollection<PlaceInfoTable>>($"{URL}/PlaceInfoTables");
                    if (Data != null)
                    {
                        PlaceInfoViewModel.InfoTables.Clear();
                        foreach (var item in Data)
                        {
                            PlaceInfoViewModel.InfoTables.Add(new PlaceInfoTable(item.PlaceInfoId, item.Place, item.RegisterDateTime, item.UpdateDateTime, item.Remarks));
                        }
                    }
                }
                else if (infoViewModel == EnumViewModel.Vendor)
                {
                    var Data = await client.GetFromJsonAsync<ObservableCollection<VendorInfoTable>>($"{URL}/VendorInfoTables");
                    if (Data != null)
                    {
                        VendorInfoViewModel.InfoTables.Clear();
                        foreach (var item in Data)
                        {
                            VendorInfoViewModel.InfoTables.Add(new VendorInfoTable(item.VendorCode,item.VendorName,item.ModelNumber, item.Category, item.RegisterDateTime, item.UpdateDateTime, item.Remarks));
                        }
                    }
                }
                else if (infoViewModel == EnumViewModel.Equipment)
                {
                    var Data = await client.GetFromJsonAsync<ObservableCollection<EquipmentInfoTable>>($"{URL}/EquipmentInfoTables");
                    if (Data != null)
                    {
                        EquipmentInfoViewModel.InfoTables.Clear();
                        foreach (var item in Data)
                        {
                            EquipmentInfoViewModel.InfoTables.Add(new EquipmentInfoTable(item.EquipmentInfoId, item.MacAddress, item.IpAddress,item.HostName,item.VendorName,item.Category,item.ModelNumber,item.Place, item.RegisterDateTime, item.UpdateDateTime, item.Remarks));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                #if DEBUG
                    //MessageBox.Show($"Error: {ex.Message}");
                    MessageBox.Show($"{ClientErrorMessage}");
                #else
                    MessageBox.Show($"{ClientErrorMessage}");
                #endif
            }
        }

        #endregion

        #region CREATE REGION

        public static void CreateTableData(EnumViewModel enumViewModel,InfoTable infoTable)
        {
            try
            {
                if (!CreateTableWithTimeout(enumViewModel, infoTable, 5000))
                {
                    MessageBox.Show($"{TimeoutMessage}");
                }
            }
            catch (Exception ex)
            {
                #if DEBUG
                    //MessageBox.Show($"Error: {ex.Message}");
                    MessageBox.Show($"{ClientErrorMessage}");
                #else
                    MessageBox.Show($"{ClientErrorMessage}");
                #endif
            }
        }
        private static bool CreateTableWithTimeout(EnumViewModel enumViewModel, InfoTable infoTable, int timeoutMilliseconds)
        {
            var task = Task.Run(() => CreateTableAsync(enumViewModel,infoTable));
            return task.Wait(timeoutMilliseconds);
        }
        private static async Task<string> CreateTableAsync(EnumViewModel enumViewModel, InfoTable infoTable)
        {
            if (enumViewModel == EnumViewModel.IpMonitor)
            {
                Response = await client.PostAsJsonAsync($"{URL}/IpMonitorInfoTables", (IpMonitorInfoTable)infoTable);
            }
            else if (enumViewModel == EnumViewModel.MacMonitor)
            { 
                Response = await client.PostAsJsonAsync($"{URL}/MacMonitorInfoTables", (MacMonitorInfoTable)infoTable);
            }
            else if (enumViewModel == EnumViewModel.Place)
            {
                Response = await client.PostAsJsonAsync($"{URL}/PlaceInfoTables", (PlaceInfoTable)infoTable);
            }
            else if (enumViewModel == EnumViewModel.Vendor)
            {
                Response = await client.PostAsJsonAsync($"{URL}/VendorInfoTables", (VendorInfoTable)infoTable);
            }
            else if (enumViewModel == EnumViewModel.Equipment)
            {
                Response = await client.PostAsJsonAsync($"{URL}/EquipmentInfoTables", (EquipmentInfoTable)infoTable);
            }
            Response.EnsureSuccessStatusCode();
            return await Response.Content.ReadAsStringAsync();
        }

        #endregion

        #region DELETE REGION

        public static void DeleteTableData(EnumViewModel enumViewModel,string id)
        {
            try
            {
                if (!DeleteTableWithTimeout(enumViewModel,id, 5000)) 
                {
                    MessageBox.Show("処理がタイムアウトしました。");
                }
            } 
            catch (Exception ex)
            {
                #if DEBUG
                    //MessageBox.Show($"Error: {ex.Message}");
                    MessageBox.Show($"{ClientErrorMessage}");
                #else
                    MessageBox.Show($"{ClientErrorMessage}");
                #endif
            }
        }
        private static bool DeleteTableWithTimeout(EnumViewModel enumViewModel, string id, int timeoutMilliseconds)
        {
            var task = Task.Run(() => DeleteTableAsync(enumViewModel,id));
            return task.Wait(timeoutMilliseconds);
        }
        private static async Task<string> DeleteTableAsync(EnumViewModel enumViewModel, string id)
        {
            if (enumViewModel == EnumViewModel.IpMonitor)
            {
                Response = await client.DeleteAsync($"{URL}/IpMonitorInfoTables/{id}");
            }
            else if (enumViewModel == EnumViewModel.MacMonitor)
            { 
                Response = await client.DeleteAsync($"{URL}/MacMonitorInfoTables/{id}");
            }
            else if (enumViewModel == EnumViewModel.Place)
            {
                Response = await client.DeleteAsync($"{URL}/PlaceInfoTables/{id}");
            }
            else if (enumViewModel == EnumViewModel.Vendor)
            {
                Response = await client.DeleteAsync($"{URL}/VendorInfoTables/{id}");
            }
            else if (enumViewModel == EnumViewModel.Equipment)
            {
                Response = await client.DeleteAsync($"{URL}/EquipmentInfoTables/{id}");
            }
            Response.EnsureSuccessStatusCode();
            return await Response.Content.ReadAsStringAsync();
        }

        #endregion

        #region DELETE ALL REGION
        public static void DeleteAllTableData(EnumViewModel enumViewModel)
        {
            try
            {
                if (!DeleteAllWithTimeout(enumViewModel, 5000))
                {
                    MessageBox.Show($"{TimeoutMessage}");
                }
            }
            catch (Exception ex)
            {
                #if DEBUG
                    //MessageBox.Show($"Error: {ex.Message}");
                    MessageBox.Show($"{ClientErrorMessage}");
                #else
                    MessageBox.Show($"{ClientErrorMessage}");
                #endif
            }
        }
        private static bool DeleteAllWithTimeout(EnumViewModel enumViewModel, int timeoutMilliseconds)
        {
            var task = Task.Run(() => DeleteAllTableAsync(enumViewModel));
            return task.Wait(timeoutMilliseconds);
        }
        private static async Task<string> DeleteAllTableAsync(EnumViewModel enumViewModel)
        {
            if (enumViewModel == EnumViewModel.IpMonitor)
            {
                Response = await client.DeleteAsync($"{URL}/IpMonitorInfoTables");
            }
            else if (enumViewModel == EnumViewModel.MacMonitor)
            { 
                Response = await client.DeleteAsync($"{URL}/MacMonitorInfoTables");
            }
            else if (enumViewModel == EnumViewModel.Place)
            {
                Response = await client.DeleteAsync($"{URL}/PlaceInfoTables");
            }
            else if (enumViewModel == EnumViewModel.Vendor)
            {
                Response = await client.DeleteAsync($"{URL}/VendorInfoTables");
            }
            else if (enumViewModel == EnumViewModel.Equipment)
            {
                Response = await client.DeleteAsync($"{URL}/EquipmentInfoTables");
            }
            Response.EnsureSuccessStatusCode();
            return await Response.Content.ReadAsStringAsync();
        }

        #endregion

        #region UPDATE REGION

        public static void UpdateTableData(EnumViewModel enumViewModel,string id, InfoTable infoTable)
        {
            try
            {
                if (!UpdateTableWithTimeout(enumViewModel, id,infoTable, 5000))
                {
                    MessageBox.Show($"{TimeoutMessage}");
                }
            }
            catch (Exception ex)
            {
                #if DEBUG
                    //MessageBox.Show($"Error: {ex.Message}");
                    MessageBox.Show($"{ClientErrorMessage}");
                #else
                    MessageBox.Show($"{ClientErrorMessage}");
                #endif
            }
        }
        private static bool UpdateTableWithTimeout(EnumViewModel enumViewModel, string id,InfoTable infoTable, int timeoutMilliseconds)
        {
            var task = Task.Run(() => UpdateTableAsync(enumViewModel, id,infoTable));
            return task.Wait(timeoutMilliseconds);
        }
        private static async Task<string> UpdateTableAsync(EnumViewModel enumViewModel, string id,InfoTable InfoTable)
        {
            HttpResponseMessage Response = new HttpResponseMessage();

            if (enumViewModel == EnumViewModel.IpMonitor)
            {
                Response = await client.PutAsJsonAsync($"{URL}/IpMonitorInfoTables/{id}", (IpMonitorInfoTable)InfoTable);
            }
            else if (enumViewModel == EnumViewModel.MacMonitor)
            { 
                Response = await client.PutAsJsonAsync($"{URL}/MacMonitorInfoTables/{id}", (MacMonitorInfoTable)InfoTable);
            }
            else if (enumViewModel == EnumViewModel.Place)
            {
                Response = await client.PutAsJsonAsync($"{URL}/PlaceInfoTables/{id}", (PlaceInfoTable)InfoTable);
            }
            else if (enumViewModel == EnumViewModel.Vendor)
            {
                Response = await client.PutAsJsonAsync($"{URL}/VendorInfoTables/{id}", (VendorInfoTable)InfoTable);
            }
            else if (enumViewModel == EnumViewModel.Equipment)
            {
                Response = await client.PutAsJsonAsync($"{URL}/EquipmentInfoTables/{id}", (EquipmentInfoTable)InfoTable);
            }
            Response.EnsureSuccessStatusCode();
            return await Response.Content.ReadAsStringAsync();
        }

        #endregion
    }
}
