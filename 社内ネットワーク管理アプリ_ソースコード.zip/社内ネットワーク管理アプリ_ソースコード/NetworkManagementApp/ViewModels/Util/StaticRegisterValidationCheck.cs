﻿using System;
using System.Text.RegularExpressions;

namespace NetworkManagementApp.ViewModels.Util
{
    public static class StaticRegisterValidationCheck
    {
        /// <summary>
        /// 引数の文字列が半角英数字のみで構成されているかを調べる。
        /// </summary>
        /// <param name="textBox">チェック対象の文字列。</param>
        /// <returns>引数が英数字のみで構成されていればtrue、そうでなければfalseを返す。</returns>
        public static bool IsOnlyAlphanumeric(string textBox)
        {
            // 文字列の先頭から末尾までが、英数字のみとマッチするかを調べる。
            return (Regex.IsMatch(textBox, @"^[0-9a-zA-Z]+$"));
        }

        /// <summary>
        /// 引数の文字列がX文字以下であるかを調べる。
        /// </summary>
        /// <param name="textBoxLength">チェック対象の文字列の数。</param>
        /// <returns>引数がX文字以下であればtrue、そうでなければfalseを返す。</returns>
        public static bool IsWithin_X_Characters(UInt16 X, int textBoxLength)
        {
            return textBoxLength <= X;
        }

        /// <summary>
        /// 引数の文字列がX文字であるかを調べる。
        /// </summary>
        /// <param name="textBox">チェック対象の文字列。</param>
        /// <returns>引数がX文字であれば、そうでなければfalseを返す。</returns>
        public static bool Is_X_Characters(UInt16 X, int textBoxLength)
        {

            return textBoxLength == X;
        }


    }
}
