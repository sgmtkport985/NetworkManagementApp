﻿using NetworkManagementApp.Models;
using NetworkManagementApp.Views;

namespace NetworkManagementApp.ViewModels.Util
{
    public static class FactryWindows
    {

        // PlaceInfo
        public static PlaceInfoWindow GetPlaceInfoWindow(MainWindow mainWindow) 
        {
            return new PlaceInfoWindow(mainWindow);
        }

        public static PlaceInfoRegisterWindow GetPlaceInfoRegisterWindow(MainWindow mainWindow)
        {
            return new PlaceInfoRegisterWindow(mainWindow);
        }

        public static PlaceInfoRegisterWindow GetPlaceInfoUpdateWindow(bool isUpdate,MainWindow mainWindow, PlaceInfoTable SelectedPlaceInfoTable)
        {
            return new PlaceInfoRegisterWindow(isUpdate,mainWindow, SelectedPlaceInfoTable);
        }


        // VendorInfo
        public static VendorInfoWindow GetVendorInfoWindow(MainWindow mainWindow)
        { 
            return new VendorInfoWindow(mainWindow);
        }

        public static VendorInfoRegisterWindow GetVendorInfoRegisterWindow(MainWindow mainWindow)
        {
            return new VendorInfoRegisterWindow(mainWindow);
        }

        public static VendorInfoRegisterWindow GetVendorInfoUpdateWindow(bool isUpdate, MainWindow mainWindow, VendorInfoTable SelectedVendorInfoTable)
        {
            return new VendorInfoRegisterWindow(isUpdate, mainWindow, SelectedVendorInfoTable);
        }

        // EquipmentInfo
        public static EquipmentInfoWindow GetEquipmentInfoWindow(MainWindow mainWindow)
        {
            return new EquipmentInfoWindow(mainWindow);
        }

        public static EquipmentInfoRegisterWindow GetEquipmentInfoRegisterWindow(MainWindow mainWindow)
        {
            return new EquipmentInfoRegisterWindow(mainWindow);
        }

        public static EquipmentInfoRegisterWindow GetEquipmentInfoUpdateWindow(bool isUpdate, MainWindow mainWindow, EquipmentInfoTable SelectedEquipmentInfoTable)
        {
            return new EquipmentInfoRegisterWindow(isUpdate, mainWindow, SelectedEquipmentInfoTable);
        }

        // IpMonitor

        
        public static IpMonitorInfoWindow GetIpMonitorInfoWindow(MainWindow mainWindow)
        {
            return new IpMonitorInfoWindow(mainWindow);
        }

        public static IpMonitorInfoRegisterWindow GetIpMonitorInfoRegisterWindow(MainWindow mainWindow)
        {
            return new IpMonitorInfoRegisterWindow(mainWindow);
        }

        public static IpMonitorInfoRegisterWindow GetIpMonitorInfoUpdateWindow(bool isUpdate, MainWindow mainWindow, IpMonitorInfoTable SelectedIpMonitorInfoTable)
        {
            return new IpMonitorInfoRegisterWindow(isUpdate, mainWindow, SelectedIpMonitorInfoTable);
        }

        // MacMonitor
        public static MacMonitorInfoWindow GetMacMonitorInfoWindow(MainWindow mainWindow)
        {
            return new MacMonitorInfoWindow(mainWindow);
        }

        public static MacMonitorInfoRegisterWindow GetMacMonitorInfoRegisterWindow(MainWindow mainWindow)
        {
            return new MacMonitorInfoRegisterWindow(mainWindow);
        }

        public static MacMonitorInfoRegisterWindow GetMacMonitorInfoUpdateWindow(bool isUpdate, MainWindow mainWindow, MacMonitorInfoTable SelectedMacMonitorInfoTable)
        {
            return new MacMonitorInfoRegisterWindow(isUpdate, mainWindow, SelectedMacMonitorInfoTable);
        }
    }
}
