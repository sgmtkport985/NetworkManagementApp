﻿
namespace NetworkManagementApp.ViewModels
{
    interface  IInfoExecute
    {
        void ShowInfoRegisterWindowExecute(object sender);
        void ShowBulkRegisterWindowExecute(object sender);
        void UpdateCommandExecute(object sender);
        void DeleteCommandExecute(object sender);
        void AllDeleteCommandExecute(object sender);
        void ToMainViewWinodowExecute(object sender);
        bool CanExecute(object sender);
    }
}
