﻿using Microsoft.Win32;
using Microsoft.WindowsAPICodePack.Dialogs;
using NetworkManagementApp.Models;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class VendorInfoViewModel : Base_InfoViewModel
    {
        public static ObservableCollection<VendorInfoTable> InfoTables { get; set; } = new ObservableCollection<VendorInfoTable>();

        private VendorInfoTable _SelectedInfoTable;
        public VendorInfoTable SelectedInfoTable
        {
            get { return _SelectedInfoTable; }
            set { _SelectedInfoTable = value; }
        }

        private string _InfoTablesCount;
        public override string InfoTablesCount
        {
            get { return _InfoTablesCount; }
            set
            {
                _InfoTablesCount = value;
                OnPropertyChanged(nameof(InfoTablesCount));
            }
        }

        private VendorInfoWindow VendorInfoWindow { get; set; }

        private string vendorCode;
        private string vendorName;
        private string modelNumber;
        private string category;
        private string remarks;

        private Dictionary<string, int> vendorCordsDictionary = new Dictionary<string, int>();

        public VendorInfoViewModel(MainWindow mainWindow, VendorInfoWindow vendorInfoWindow)
        {

            this.mainWindow = mainWindow;
            this.VendorInfoWindow = vendorInfoWindow;

        }

        public override void ShowBulkRegisterWindowExecute(object sender)
        {
            // ダイアログのインスタンスを生成
            var dialog = new OpenFileDialog();

            // ファイルの種類を設定
            dialog.Filter = "tsvファイル (*.tsv)|*.tsv";

            // ダイアログを表示する
            if (dialog.ShowDialog() == true)
            {
                // 選択されたファイル名 (ファイルパス) をメッセージボックスに表示
                using (FileStream fs = new FileStream(dialog.FileName, FileMode.Open))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        try
                        {
                            string line;
                            int lineCount = 0;
                            string[] lineSplit;

                            string[] DataArray = new string[5];
                            List<string[]> DataList = new List<string[]>();

                            while ((line = sr.ReadLine()) != null)
                            {
                                if (lineCount == 0)
                                {
                                    lineCount++;
                                    continue;
                                }
                                lineSplit = line.Split('\t');

                                //
                                vendorCode = lineSplit[0];
                                vendorName = lineSplit[1];
                                modelNumber = lineSplit[2];
                                category = lineSplit[3];
                                remarks = lineSplit[4];

                                //
                                BulkRegisterValidationCheck();

                                // ベンダーコード	ベンダー名	型番	機器種別名	備考
                                DataArray = new string[5] {vendorCode ,vendorName,modelNumber, category, remarks };
                                DataList.Add(DataArray);

                                lineCount++;
                            }

                            lineCount -= 1;

                            string text =
                                $"{lineCount} 件を一括登録します。\n" +
                                $"\n" +
                                $"よろしいですか？";

                            MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                            if (result == MessageBoxResult.Yes)
                            {

                                foreach (string[] array in DataList)
                                {
                                    vendorCode = array[0];
                                    vendorName = array[1];
                                    modelNumber = array[2];
                                    category = array[3];
                                    remarks = array[4];

                                    string nowString = DateTime.Now.ToString();

                                    WebApiClient.CreateTableData(EnumViewModel.Vendor, new VendorInfoTable(
                                        vendorCode.ToUpper(),
                                        vendorName,
                                        modelNumber,
                                        category,
                                        nowString,
                                        nowString,
                                        remarks
                                    ));
                                }
                                SetTables();
                                SetTablesCount();
                                MessageBox.Show($"{lineCount} 件を一括登録しました。");

                                //
                                DataList.Clear();
                                vendorCordsDictionary.Clear();
                            }
                        }
                        catch (ValidationCheckException e)
                        {
                            MessageBox.Show(e.Message);
                        }
                        catch (Exception e)
                        {
                            MessageBox.Show(e.Message);
                        }
                    }
                }
            }
        }
        public override void DeleteCommandExecute(object sender)
        {
            if (SelectedInfoTable.VendorCode == "-1")
            {
                MessageBox.Show("行が選択されていません。");
            }
            else
            {
                string code = SelectedInfoTable.VendorCode;
                string text = $"ベンダーコード : {code} を削除します。\n\nよろしいですか？";

                MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {

                    WebApiClient.DeleteTableData(EnumViewModel.Vendor,code);

                    SetTables();
                    VendorInfoRegisterViewModel.VendorCordsDictionary.Remove(code);

                    MessageBox.Show($"ベンダーコード : {code} を削除しました。");
                }
            }
        }
        public override void UpdateCommandExecute(object sender)
        {
            if (SelectedInfoTable.VendorCode == "-1")
            {
                MessageBox.Show("行が選択されていません。");

            }
            else
            {
                VendorInfoRegisterWindow vendorInfoUpdateWindow = FactryWindows.GetVendorInfoUpdateWindow(true, mainWindow, SelectedInfoTable);
                vendorInfoUpdateWindow.Show();
                VendorInfoWindow.Close();
            }
        }
        public override void AllDeleteCommandExecute(object sender)
        {
            MessageBoxResult result = MessageBox.Show("すべての登録情報を削除します。\n\nよろしいですか？", "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {

                WebApiClient.DeleteAllTableData(EnumViewModel.Vendor);

                ClearTables(); 
                SetTablesCount();
                VendorInfoRegisterViewModel.VendorCordsDictionary.Clear();

                MessageBox.Show("すべての登録情報を削除しました。");
            }
        }
        public override bool CanExecute(object sender)
        {
            return true;
        }
        public override void ShowInfoRegisterWindowExecute(object sender)
        {
            VendorInfoRegisterWindow vendorInfoRegisterWindow = FactryWindows.GetVendorInfoRegisterWindow(mainWindow);
            vendorInfoRegisterWindow.Show();
            VendorInfoWindow.Close();
        }
        public override void ToMainViewWinodowExecute(object sender)
        {
            mainWindow.Show();
            VendorInfoWindow.Close();
        }
        public override void OutputAllDataCommandExecute(object sender)
        {
            //throw new NotImplementedException();
            MessageBox.Show("出力先フォルダを選択してください。");

            // データ出力
            using (CommonOpenFileDialog cofd = new CommonOpenFileDialog())
            {
                // フォルダを選択できるようにする
                cofd.IsFolderPicker = true;

                if (cofd.ShowDialog() == CommonFileDialogResult.Ok)
                {
                    //MessageBox.Show($"{cofd.FileName}");

                    using (FileStream fs = new FileStream($"{cofd.FileName}" + "\\ベンダー情報データ出力結果_" + $"{DateTime.Now.ToString("yyyy.MM.dd")}" + ".tsv", FileMode.Create, FileAccess.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(fs))
                        {
                            try
                            {
                                sw.WriteLine("ベンダーコード\tベンダー名\t機器種別名\t登録日時\t更新日時\t備考");
                                foreach (VendorInfoTable InfoTable in InfoTables)
                                {
                                    sw.WriteLine($"{InfoTable.VendorCode}\t{InfoTable.VendorName}\t{InfoTable.Category}\t{InfoTable.RegisterDateTime}\t{InfoTable.UpdateDateTime}\t{InfoTable.Remarks}");
                                }
                            }
                            catch (Exception e)
                            {
                                MessageBox.Show(e.Message);
                            }
                        }
                    }
                }
            }
        }

        protected override async void SetTables()
        {
            ClearTables();

            WebApiClient.ReadTableData(EnumViewModel.Vendor);
            await Task.Delay(100);
            SetTablesCount();

            SelectedInfoTable = new VendorInfoTable() { VendorCode = "-1" };

        }
        protected override void ClearTables()
        {
            if (InfoTables.Count >= 1)
            {
                for (int i = InfoTables.Count - 1; i >= 0; i--)
                {
                    InfoTables.RemoveAt(i);
                }
            }
        }
        protected override void SetTablesCount()
        {
            string tablesCount = InfoTables.Count.ToString();
            string text = $"表示件数：　{tablesCount}　件";
            InfoTablesCount = text;
        }
        protected override void BulkRegisterValidationCheck()
        {
            //
            if (vendorCode != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, vendorCode.Length))
                {
                    throw new ValidationCheckException("【ベンダーコード】入力文字数が適切ではありません。");
                }
            }

            foreach(var val in InfoTables)
            {
                if (val.VendorCode == vendorCode)
                { 
                    throw new ValidationCheckException("【ベンダーコード】重複しています。");
                }
            }

            if (vendorName != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, vendorName.Length))
                {
                    throw new ValidationCheckException("【ベンダー名】入力文字数が適切ではありません。");
                }
            }

            if (modelNumber != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, modelNumber.Length))
                {
                    throw new ValidationCheckException("【型番】入力文字数が適切ではありません。");
                }
            }

            if (category == null || category == "")
            {
                throw new ValidationCheckException("【機器種別名】選択されていません。");
            }

            if (!CategoryModel.Categorys.Contains(category))
            {
                throw new ValidationCheckException("【機器種別名】存在しない情報です。");
            }

            if (remarks != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, remarks.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }
    }
}
