﻿using Microsoft.Win32;
using Microsoft.WindowsAPICodePack.Dialogs;
using NetworkManagementApp.Models;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class EquipmentInfoViewModel : Base_InfoViewModel
    {
        public static Dictionary<string, int> PlaceDictionary { get; set; } = new Dictionary<string, int>();
        public static ObservableCollection<EquipmentInfoTable> InfoTables { get; set; } = new ObservableCollection<EquipmentInfoTable>();

        private EquipmentInfoTable _SelectedInfoTable;
        public EquipmentInfoTable SelectedInfoTable
        {
            get { return _SelectedInfoTable; }
            set { _SelectedInfoTable = value; }
        }

        private EquipmentInfoWindow EquipmentInfoWindow { get; set; }
        private Dictionary<string, string> DictionaryVendorCodeVendorName { get; set; }
        private Dictionary<string, string> DictionaryVendorCodeCategory { get; set; }

        private string macAddress, ipAddress, hostName, place, remarks;

        public EquipmentInfoViewModel(MainWindow mainWindow, EquipmentInfoWindow equipmentInfoWindow)
        {
            this.mainWindow = mainWindow;
            this.EquipmentInfoWindow = equipmentInfoWindow;

            MakePlaceDic();
            MakeDictionaryVendorNameCategory();
        }

        public override void AllDeleteCommandExecute(object sender)
        {
            MessageBoxResult result = MessageBox.Show("すべての登録情報を削除します。\n\nよろしいですか？", "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {

                WebApiClient.DeleteAllTableData(EnumViewModel.Equipment);

                ClearTables();
                SetTablesCount();


                MessageBox.Show("すべての登録情報を削除しました。");
            }
        }
        public override void DeleteCommandExecute(object sender)
        {
            if (SelectedInfoTable.EquipmentInfoId == -1)
            {
                MessageBox.Show("行が選択されていません。");
            }
            else
            {
                int id = SelectedInfoTable.EquipmentInfoId;
                string text = $"機器情報Id : {id} を削除します。\n\nよろしいですか？";

                MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {

                    WebApiClient.DeleteTableData(EnumViewModel.Equipment,id.ToString());

                    SetTables();
                    MessageBox.Show($"機器情報Id : {id} を削除しました。");
                }
            }
        }
        public override void ShowBulkRegisterWindowExecute(object sender)
        {
            // ダイアログのインスタンスを生成
            var dialog = new OpenFileDialog();

            // ファイルの種類を設定
            dialog.Filter = "tsvファイル (*.tsv)|*.tsv";

            // ダイアログを表示する
            if (dialog.ShowDialog() == true)
            {
                // 選択されたファイル名 (ファイルパス) をメッセージボックスに表示
                using (FileStream fs = new FileStream(dialog.FileName, FileMode.Open))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        try
                        {
                            string line;
                            int lineCount = 0;
                            string[] lineSplit;

                            string[] DataArray = new string[5];
                            List<string[]> DataList = new List<string[]>();

                            while ((line = sr.ReadLine()) != null)
                            {
                                if (lineCount == 0)
                                {
                                    lineCount++;
                                    continue;
                                }
                                lineSplit = line.Split('\t');

                                //
                                int i=0;
                                macAddress = lineSplit[i++];
                                ipAddress = lineSplit[i++];
                                hostName = lineSplit[i++];
                                place = lineSplit[i++];
                                remarks = lineSplit[i++];

                                BulkRegisterValidationCheck();

                                // MACアドレス	IPアドレス	ホスト名	設置場所	備考
                                DataArray = new string[5] { macAddress,ipAddress,hostName,place, remarks };
                                DataList.Add(DataArray);

                                lineCount++;
                            }

                            lineCount -= 1;

                            string text =
                                $"{lineCount} 件を一括登録します。\n" +
                                $"\n" +
                                $"よろしいですか？";

                            MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                            if (result == MessageBoxResult.Yes)
                            {

                                foreach (string[] array in DataList)
                                {
                                    int i = 0;
                                    macAddress = array[i++];
                                    ipAddress = array[i++];
                                    hostName = array[i++];
                                    place = array[i++];
                                    remarks = array[i++];

                                    string nowString = DateTime.Now.ToString();

                                    string vendorCode = GetVendorCode(macAddress);

                                    WebApiClient.CreateTableData(EnumViewModel.Equipment,new EquipmentInfoTable(
                                        macAddress,
                                        ipAddress,
                                        hostName,
                                        GetVendorName(vendorCode),
                                        GetCategory(vendorCode),
                                        place,
                                        nowString,
                                        nowString,
                                        remarks
                                        ));

                                }
                                SetTables();
                                SetTablesCount();
                                MessageBox.Show($"{lineCount} 件を一括登録しました。");
                                DataList.Clear();
                                PlaceDictionary.Clear();
                            }
                        }
                        catch (ValidationCheckException e)
                        {
                            MessageBox.Show(e.Message);
                        }
                        catch (Exception e)
                        {
                            MessageBox.Show(e.Message);
                        }
                    }
                }
            }
        }
        public override void ShowInfoRegisterWindowExecute(object sender)
        {
            EquipmentInfoRegisterWindow equipmentInfoRegisterWindow = new EquipmentInfoRegisterWindow(mainWindow);
            equipmentInfoRegisterWindow.Show();
            EquipmentInfoWindow.Close();
        }
        public override void ToMainViewWinodowExecute(object sender)
        {
            mainWindow.Show();
            EquipmentInfoWindow.Close();
        }
        public override void UpdateCommandExecute(object sender)
        {
            if (SelectedInfoTable.EquipmentInfoId == -1)
            {
                MessageBox.Show("行が選択されていません。");
            }
            else
            {
                EquipmentInfoRegisterWindow equipmentInfoUpdateWindow = FactryWindows.GetEquipmentInfoUpdateWindow(true, mainWindow, SelectedInfoTable);
                equipmentInfoUpdateWindow.Show();
                EquipmentInfoWindow.Close();
            }
        }
        public override void OutputAllDataCommandExecute(object sender)
        {
            //throw new NotImplementedException();
            MessageBox.Show("出力先フォルダを選択してください。");

            // データ出力
            using (CommonOpenFileDialog cofd = new CommonOpenFileDialog())
            {
                // フォルダを選択できるようにする
                cofd.IsFolderPicker = true;

                if (cofd.ShowDialog() == CommonFileDialogResult.Ok)
                {
                    //MessageBox.Show($"{cofd.FileName}");

                    using (FileStream fs = new FileStream($"{cofd.FileName}" + "\\機器情報データ出力結果_" + $"{DateTime.Now.ToString("yyyy.MM.dd")}" + ".tsv", FileMode.Create, FileAccess.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(fs))
                        {
                            try
                            {
                                sw.WriteLine("機器情報id\tMACアドレス\tIPアドレス\tホスト名\tベンダー名\t機器種別名\t型番\t設置場所\t登録日時\t更新日時\t備考");
                                foreach (EquipmentInfoTable InfoTable in InfoTables)
                                {
                                    sw.WriteLine($"{InfoTable.EquipmentInfoId}\t{InfoTable.MacAddress}\t{InfoTable.IpAddress}\t{InfoTable.HostName}\t{InfoTable.VendorName}\t{InfoTable.Category}\t{InfoTable.Place}\t{InfoTable.RegisterDateTime}\t{InfoTable.UpdateDateTime}\t{InfoTable.Remarks}");
                                }
                            }
                            catch (Exception e)
                            {
                                MessageBox.Show(e.Message);
                            }
                        }
                    }
                }
            }
        }

        protected override async void SetTables()
        {
            InfoTables.Clear();

            WebApiClient.ReadTableData(EnumViewModel.Equipment);
            await Task.Delay(100);
            SetTablesCount();

            SelectedInfoTable = new EquipmentInfoTable() { EquipmentInfoId = -1 };
        }
        protected override void ClearTables()
        {
            if (InfoTables.Count >= 1)
            {
                for (int i = InfoTables.Count - 1; i >= 0; i--)
                {
                    InfoTables.RemoveAt(i);
                }
            }
        }
        protected override void SetTablesCount()
        {
            string infoTablesCount = InfoTables.Count.ToString();
            string text = $"表示件数：　{infoTablesCount}　件";
            InfoTablesCount = text;
        }
        protected override void BulkRegisterValidationCheck()
        {

            if (macAddress == null || macAddress == "")
            {
                throw new ValidationCheckException("【MACアドレス】未入力です。");
            }

            foreach (var val in InfoTables)
            {
                if (val.MacAddress == macAddress)
                {
                    throw new ValidationCheckException($"【MACアドレス】重複しています。\n\n{macAddress}");
                }
            }

            if (ipAddress == null || ipAddress == "")
            {
                throw new ValidationCheckException("【IPアドレス】未入力です。");
            }

            if (place == null || ipAddress == "")
            {
                throw new ValidationCheckException("【設置場所】未選択です。");
            }

            if (place != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, place.Length))
                {
                    throw new ValidationCheckException("【設置場所】入力文字数が適切ではありません。");
                }
            }

            // 【設置場所】存在しない情報です。
            if (!PlaceDictionary.ContainsKey(place))
            {
                throw new ValidationCheckException("【設置場所】存在しない情報です。");
            }

            if (remarks != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, remarks.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }

        private async void MakePlaceDic()
        {
            PlaceDictionary.Clear();

            WebApiClient.ReadTableData(EnumViewModel.Place);
            await Task.Delay(100);

            foreach (var val in PlaceInfoViewModel.InfoTables)
            {
                PlaceDictionary[val.Place] = 1;
            }
        }
        private async void MakeDictionaryVendorNameCategory()
        {
            WebApiClient.ReadTableData(EnumViewModel.Vendor);
            await Task.Delay(100);

            foreach (var val in VendorInfoViewModel.InfoTables)
            {
                DictionaryVendorCodeVendorName[val.VendorCode] = val.VendorName;
                DictionaryVendorCodeCategory[val.VendorCode] = val.Category;
            }
        }
        private string GetVendorName(string VendorCode)
        {
            if (DictionaryVendorCodeVendorName.ContainsKey(VendorCode))
            { 
                return DictionaryVendorCodeVendorName[VendorCode];
            }
            return "";
        }
        private string GetCategory(string VendorCode)
        {
            if (DictionaryVendorCodeCategory.ContainsKey(VendorCode))
            {
                return DictionaryVendorCodeCategory[VendorCode];
            }
            return "";
        }
        private string GetVendorCode(string macAddress)
        {
            string macAddressUpper = macAddress.ToUpper();
            string macAddressUpperIsDot;
            string vendorCode = "";

            if (macAddressUpper.Contains('-'))
            {
                macAddressUpperIsDot = macAddressUpper.Replace('-', '.');
            }
            else if (macAddressUpper.Contains(';'))
            {
                macAddressUpperIsDot = macAddressUpper.Replace(';', '.');
            }
            else
            {
                macAddressUpperIsDot = macAddressUpper;
            }

            foreach (char c in macAddressUpperIsDot)
            {
                if (c != '.')
                {
                    vendorCode += c;
                }
            }

            return vendorCode.Substring(0,6);
        }
    }
}
