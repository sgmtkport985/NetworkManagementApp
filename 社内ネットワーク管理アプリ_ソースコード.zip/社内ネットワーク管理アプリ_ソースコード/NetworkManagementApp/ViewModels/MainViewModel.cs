﻿using NetworkManagementApp.Models;
using NetworkManagementApp.MVVM;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class MainViewModel : Base_InfoViewModel
    {
        public RelayCommand ShowEquipmentInfoWindow { get; set; }
        public RelayCommand ShowVendorInfoWindow { get; set; }
        public RelayCommand ShowPlaceInfoWindow { get; set; }
        public RelayCommand ShowIpMonitorInfoWindow { get; set; }
        public RelayCommand ShowMacMonitorInfoWindow { get; set; }
        public RelayCommand ApplicationShutdown { get; set; }

        public static ObservableCollection<MainMonitorTable> InfoTables { get; set; } = new ObservableCollection<MainMonitorTable>();

        List<string> macAddresList = new List<string>();

        #region OnPropertyChanged Poperty

        /*
        private int _ConnectionSpeedAVG;
        public int ConnectionSpeedAVG
        {
            get { return _ConnectionSpeedAVG; }
            set
            {
                _ConnectionSpeedAVG = value;
                OnPropertyChanged();
            }
        }
        */
        private string _UnkownCount;
        public string UnkownCount
        {
            get { return _UnkownCount; }
            set
            {
                _UnkownCount = value;
                OnPropertyChanged();
            }
        }

        private string _IpMonitorCount;
        public string IpMonitorCount
        {
            get { return _IpMonitorCount; }
            set
            {
                _IpMonitorCount = value;
                OnPropertyChanged();
            }
        }

        private string _MacMonitorCount;
        public string MacMonitorCount
        {
            get { return _MacMonitorCount; }
            set
            {
                _MacMonitorCount = value;
                OnPropertyChanged();
            }
        }

        private string _NWCount;
        public string NWCount
        {
            get { return _NWCount; }
            set
            {
                _NWCount = value;
                OnPropertyChanged();
            }
        }

        private string _PCCount;
        public string PCCount
        {
            get { return _PCCount; }
            set
            {
                _PCCount = value;
                OnPropertyChanged();
            }
        }

        private string _PRCount;
        public string PRCount
        {
            get { return _PRCount; }
            set
            {
                _PRCount = value;
                OnPropertyChanged();
            }
        }

        #endregion

        Dictionary<string, string> MacAddressVendorNameDictionary = new Dictionary<string, string>();
        Dictionary<string, string> MacAddressCategoryDictionary = new Dictionary<string, string>();
        Dictionary<string, string> MacAddressHostNameDictionary = new Dictionary<string, string>();
        Dictionary<string, string> MacAddressPlaceDictionary = new Dictionary<string, string>();
        Dictionary<string, string> MacAddressRemarkDictionaryForMacMonitor = new Dictionary<string, string>();
        Dictionary<string, string> IpAddressRemarkDictionaryForIpMonitor = new Dictionary<string, string>();


        public MainViewModel(MainWindow mainWindow)
        {

            this.mainWindow = mainWindow;

            ReadTableDatas();

            ShowEquipmentInfoWindow = new RelayCommand(ShowEquipmentInfoWindowExecute, CanExecute);
            ShowVendorInfoWindow = new RelayCommand(ShowVendorInfoWindowExecute, CanExecute);
            ShowPlaceInfoWindow = new RelayCommand(ShowPlaceInfoWindowExecute, CanExecute);
            ShowIpMonitorInfoWindow = new RelayCommand(ShowIpMonitorInfoWindowExecute, CanExecute);
            ShowMacMonitorInfoWindow = new RelayCommand(ShowMacMonitorInfoWindowExecute, CanExecute);
            ApplicationShutdown = new RelayCommand(ApplicationShutdownExecute, CanExecute);

            InfoTables.Clear();
            MakeDictionary();
            SetTables();

            DispatcherTimer loopTimer = new DispatcherTimer();
            loopTimer.Interval = new TimeSpan(0, 0, 5);
            loopTimer.Tick += new EventHandler(TimerAction);
            loopTimer.Start();
           
        }

        private void TimerAction(object sender, EventArgs e)
        {
            InfoTables.Clear();
            MakeDictionary();
            SetTables();
        }

        void ReadArpTable()
        {
            try
            {
                string curDir = Directory.GetCurrentDirectory();
                string path = curDir + @"\ExternalFiles\ArpTable.log";
                using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        string line = "";

                        int unkownCount = 0;
                        int ipMonitorCount = 0;
                        int macMonitorCount = 0;
                        int nwCount = 0;
                        int pcCount = 0;
                        int prCount = 0;

                        WebApiClient webApiClient = new WebApiClient();


                        while ((line = sr.ReadLine()) != null)
                        {
                            string[] lineSplit = line.Split('\t');
                            string macAddress = lineSplit[0];
                            string ipAddress = lineSplit[1];
                            
                            MainMonitorTable mainMonitorTable = new MainMonitorTable();
                            mainMonitorTable.MacAddress = macAddress;
                            mainMonitorTable.VendorName = GetVendorName(macAddress);
                            mainMonitorTable.Category = GetCategory(macAddress);
                            mainMonitorTable.IpAddress = ipAddress;
                            mainMonitorTable.VLAN = GetVLAN(ipAddress);
                            mainMonitorTable.HostName = GetHostName(macAddress);
                            mainMonitorTable.Place = GetPlace(macAddress);
                            mainMonitorTable.IsIpAddressMonitor = GetIpRemarks(ipAddress);
                            mainMonitorTable.IsMacAddressMonitor = GetMacRemarks(macAddress);

                            if (mainMonitorTable.VendorName == "")
                            { 
                                unkownCount++;
                            }

                            if (mainMonitorTable.IsIpAddressMonitor != "")
                            { 
                                ipMonitorCount++;
                            }

                            if (mainMonitorTable.IsMacAddressMonitor != "")
                            { 
                                macMonitorCount++;
                            }

                            if (mainMonitorTable.Category == "ＰＣ")
                            { 
                                pcCount++;
                            }

                            if (mainMonitorTable.Category == "ＮＷ")
                            {
                                nwCount++;
                            }

                            if (mainMonitorTable.Category == "ＰＲ")
                            {
                                prCount++;
                            }

                            InfoTables.Add(mainMonitorTable);
                        }

                        UnkownCount     = $"不明な機器 : {unkownCount} 件";
                        IpMonitorCount  = $"IP監視 : {ipMonitorCount} 件";
                        MacMonitorCount = $"MAC監視 : {macMonitorCount} 件";

                        NWCount = $"ＮＷ機器 : {nwCount} 件";
                        PCCount = $"ＰＣ機器 : {pcCount} 件";
                        PRCount = $"ＰＲ機器 : {prCount} 件";

                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void ReadTableDatas()
        { 
            WebApiClient.ReadTableData(EnumViewModel.Equipment);
            WebApiClient.ReadTableData(EnumViewModel.IpMonitor);
            WebApiClient.ReadTableData(EnumViewModel.MacMonitor);
        }

        private async void MakeDictionary()
        {
            await Task.Delay(100);

            foreach (var val in EquipmentInfoViewModel.InfoTables)
            {
                MacAddressVendorNameDictionary[val.MacAddress] = val.VendorName;
                MacAddressCategoryDictionary[val.MacAddress] = val.Category;
                MacAddressHostNameDictionary[val.MacAddress] = val.HostName;
                MacAddressPlaceDictionary[val.MacAddress] = val.Place;
            }

            foreach (var val in IpMonitorInfoViewModel.InfoTables)
            {
                IpAddressRemarkDictionaryForIpMonitor[val.IPAddress] = val.Remarks;
            }

            foreach (var val in MacMonitorInfoViewModel.InfoTables)
            {
                MacAddressRemarkDictionaryForMacMonitor[val.MACAddress] = val.Remarks;
            }
        }

        string GetIpRemarks(string ipAddress)
        {
            if (IpAddressRemarkDictionaryForIpMonitor.ContainsKey(ipAddress))
            {
                return IpAddressRemarkDictionaryForIpMonitor[ipAddress];
            }
            else
            {
                return "";
            }
        }

        string GetMacRemarks(string macAddress)
        {
            if (MacAddressRemarkDictionaryForMacMonitor.ContainsKey(macAddress))
            {
                return MacAddressRemarkDictionaryForMacMonitor[macAddress];
            }
            else
            {
                return "";
            }
        }

        string GetPlace(string macAddress)
        {
            if (MacAddressPlaceDictionary.ContainsKey(macAddress))
            {
                return MacAddressPlaceDictionary[macAddress];
            }
            else
            {
                return "";
            }
        }

        string GetHostName(string macAddress)
        {
            if (MacAddressHostNameDictionary.ContainsKey(macAddress))
            {
                return MacAddressHostNameDictionary[macAddress];
            }
            else
            {
                return "";
            }
        }

        string GetCategory(string macAddress)
        {
            if (MacAddressCategoryDictionary.ContainsKey(macAddress))
            {
                return MacAddressCategoryDictionary[macAddress];
            }
            else
            {
                return "";
            }
        }

        string GetVendorName(string macAddress)
        {
            if (MacAddressVendorNameDictionary.ContainsKey(macAddress))
            { 
                return MacAddressVendorNameDictionary[macAddress];
            }
            else
            {
                return "";
            }
        }

        string GetVLAN(string ipAddress)
        {
            string[] ipAddressSplit = ipAddress.Split('.');
            return ipAddressSplit[2];
        }

        public override bool CanExecute(object sender)
        {
            return true;
        }

        public void ShowEquipmentInfoWindowExecute(object sender)
        {
            EquipmentInfoWindow equipmentInfoWindow = new EquipmentInfoWindow(mainWindow);
            equipmentInfoWindow.Show();
            mainWindow.Hide();
        }

        public void ShowIpMonitorInfoWindowExecute(object sender)
        {
            IpMonitorInfoWindow ipMonitorInfoWindow = new IpMonitorInfoWindow(mainWindow,this);
            ipMonitorInfoWindow.Show();
            mainWindow.Hide();
        }

        public void ShowMacMonitorInfoWindowExecute(object sender)
        {
            MacMonitorInfoWindow macMonitorInfoWindow = new MacMonitorInfoWindow(mainWindow);
            macMonitorInfoWindow.Show();
            mainWindow.Hide();
        }

        public void ShowVendorInfoWindowExecute(object sender)
        {
            VendorInfoWindow vendorInfoWindow = new VendorInfoWindow(mainWindow);
            vendorInfoWindow.Show();
            mainWindow.Hide();
        }

        public void ShowPlaceInfoWindowExecute(object sender)
        {
            PlaceInfoWindow placeInfoWindow = FactryWindows.GetPlaceInfoWindow(mainWindow);
            placeInfoWindow.Show();
            mainWindow.Hide();
        }

        public void ApplicationShutdownExecute(object sender)
        {
            Application.Current.Shutdown();
        }

        protected override void SetTables()
        {
            ReadArpTable();
            SetTablesCount();
        }

        protected override void ClearTables()
        {
            if (InfoTables.Count >= 1)
            {
                InfoTables.Clear();
            }
        }

        protected override void SetTablesCount()
        {
            string infoTablesCount = InfoTables.Count.ToString();
            string text = $"表示件数：　{infoTablesCount}　件";
            InfoTablesCount = text;
        }

        #region NotUseMethods

        public override void DeleteCommandExecute(object sender)
        {
            throw new NotImplementedException();
        }

        public override void ShowBulkRegisterWindowExecute(object sender)
        {
            throw new NotImplementedException();
        }

        public override void ShowInfoRegisterWindowExecute(object sender)
        {
            throw new NotImplementedException();
        }

        public override void ToMainViewWinodowExecute(object sender)
        {
            throw new NotImplementedException();
        }

        public override void UpdateCommandExecute(object sender)
        {
            throw new NotImplementedException();
        }

        protected override void BulkRegisterValidationCheck()
        {
            throw new NotImplementedException();
        }

        public override void OutputAllDataCommandExecute(object sender)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
