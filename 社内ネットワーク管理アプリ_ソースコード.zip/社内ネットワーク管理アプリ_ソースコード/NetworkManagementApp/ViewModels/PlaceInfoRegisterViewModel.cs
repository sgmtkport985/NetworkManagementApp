﻿using NetworkManagementApp.Models;
using NetworkManagementApp.MVVM;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class PlaceInfoRegisterViewModel : Base_InfoRegisterViewModel
    {
        private PlaceInfoRegisterWindow placeInfoRegisterWindow { get; set; }
        private PlaceInfoWindow placeInfoWindow { get; set; }

        public static Dictionary<string, int> PlaceDictionary { get; set; } = new Dictionary<string, int>();

        private string _PlaceTextBox;
        public string PlaceTextBox 
        { 
            get{ return _PlaceTextBox; }
            set{ _PlaceTextBox = value; OnPropertyChanged(PlaceTextBox); }
        }

        private string _RemarksTextBox;
        public override string RemarksTextBox
        {
            get { return _RemarksTextBox; }
            set { _RemarksTextBox = value; OnPropertyChanged(RemarksTextBox); }
        }

        private PlaceInfoTable placeInfoTable;

        public PlaceInfoRegisterViewModel(MainWindow mainWindow, PlaceInfoRegisterWindow placeInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.placeInfoRegisterWindow = placeInfoRegisterWindow;
        }

        public PlaceInfoRegisterViewModel(PlaceInfoTable placeInfoTable, MainWindow mainWindow, PlaceInfoRegisterWindow placeInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.placeInfoRegisterWindow = placeInfoRegisterWindow;
            this.placeInfoWindow = FactryWindows.GetPlaceInfoWindow(mainWindow);

            InfoRegister = new RelayCommand(InfoUpdateExecute, CanExecute);

            this.placeInfoTable = placeInfoTable;
            PlaceTextBox = placeInfoTable.Place;
            RemarksTextBox = placeInfoTable.Remarks;
        }

        public override bool CanExecute(object sender)
        {
            return true;
        }

        public override void ToMainViewWinodowExecute(object sender)
        {
            setCollectionClear();
            mainWindow.Show();
            placeInfoRegisterWindow.Close();
        }

        public override void ToInfoWinodowExecute(object sender)
        {
            setCollectionClear();
            placeInfoWindow = FactryWindows.GetPlaceInfoWindow(mainWindow);
            placeInfoWindow.Show();
            placeInfoRegisterWindow.Close();
        }

        public override void InfoRegisterExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                RegisterValidationCheck();

                text_Info = getRegisterTextInfo(nowString);

                text = 
                    "\n\n" +
                    "上記の情報を登録します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text,"",MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {

                    WebApiClient.CreateTableData(EnumViewModel.Place,new PlaceInfoTable(PlaceTextBox,nowString,nowString, RemarksTextBox));

                    text =
                    "\n\n" +
                    "上記の情報を登録しました。";
                    MessageBox.Show(text_Info + text);
                }

                setCollectionClear();

                placeInfoWindow = FactryWindows.GetPlaceInfoWindow(mainWindow);
                placeInfoWindow.Show();
                placeInfoRegisterWindow.Close();
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public override void InfoUpdateExecute(object sender)
        {
            try
            { 
                nowString = DateTime.Now.ToString();

                UpdateValidationCheck();

                text_Info = getUpdateTextInfo(nowString);

                text = "\n\n" +
                    "上記の情報で更新します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text,"", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {

                    WebApiClient.UpdateTableData(EnumViewModel.Place,placeInfoTable.PlaceInfoId.ToString(), 
                    new PlaceInfoTable(
                        placeInfoTable.PlaceInfoId,
                        PlaceTextBox,
                        placeInfoTable.RegisterDateTime,
                        nowString,
                        RemarksTextBox
                    ));

                    text = "\n\n" +
                    "上記の情報で更新しました。";

                    MessageBox.Show(text_Info + text);

                    placeInfoWindow = FactryWindows.GetPlaceInfoWindow(mainWindow);
                    placeInfoWindow.Show();
                    placeInfoRegisterWindow.Close();
                }
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        protected override string getRegisterTextInfo(string nowString)
        {
            string RegisterText =
                "設置場所 　: " + PlaceTextBox + "\n" +
                "登録日時 　: " + nowString + "\n" +
                "更新日時 　: " + nowString + "\n" +
                "　備　考 　: " + RemarksTextBox;

            return RegisterText;
        }

        protected override string getUpdateTextInfo(string nowString)
        {
            string UpdateText =
                "設置場所Id : " + placeInfoTable.PlaceInfoId.ToString() + "\n" +
                "設置場所 　: " + PlaceTextBox + "\n" +
                "登録日時 　: " + placeInfoTable.RegisterDateTime + "\n" +
                "更新日時 　: " + nowString + "\n" +
                "　備　考 　: " + RemarksTextBox;

            return UpdateText;
        }

        protected override void setCollectionClear()
        {
            PlaceDictionary.Clear();
        }

        protected override void RegisterValidationCheck()
        {
            // null check
            if (PlaceTextBox == null || PlaceTextBox == "")
            {
                throw new ValidationCheckException("【設置場所】未入力です。");
            }

            if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, PlaceTextBox.Length))
            {
                throw new ValidationCheckException("【設置場所】入力文字数が適切ではありません。");
            }

            foreach (var val in PlaceInfoViewModel.InfoTables)
            {
                if (val.Place == PlaceTextBox)
                {
                    throw new ValidationCheckException("【設置場所】重複しています。");
                }
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }

        protected override void UpdateValidationCheck()
        {
            // null check
            if (PlaceTextBox == null || PlaceTextBox == "")
            {
                throw new ValidationCheckException("【設置場所】未入力です。");
            }

            if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, PlaceTextBox.Length))
            {
                throw new ValidationCheckException("【設置場所】入力文字数が適切ではありません。");
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }
    }
}
