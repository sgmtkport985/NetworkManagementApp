﻿using NetworkManagementApp.Models;
using NetworkManagementApp.MVVM;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class VendorInfoRegisterViewModel : Base_InfoRegisterViewModel
    {
        private VendorInfoWindow vendorInfoWindow { get; set; }

        private VendorInfoRegisterWindow vendorInfoRegisterWindow { get; set; }

        private VendorInfoTable vendorInfoTable;

        public static Dictionary<string, int> VendorCordsDictionary { get; set; } = new Dictionary<string, int>();


        private string _VendorCodeTextBox;
        public string VendorCodeTextBox
        {
            get { return _VendorCodeTextBox; }
            set { _VendorCodeTextBox = value; OnPropertyChanged(VendorCodeTextBox); }
        }

        private string _VendorNameTextBox;
        public string VendorNameTextBox
        {
            get { return _VendorNameTextBox; }
            set { _VendorNameTextBox = value; OnPropertyChanged(VendorNameTextBox); }
        }

        private string _ModelNumberTextBox;
        public string ModelNumberTextBox
        {
            get { return _ModelNumberTextBox; }
            set { _ModelNumberTextBox = value; OnPropertyChanged(ModelNumberTextBox); }
        }

        private string _CategoryComboBox;
        public string CategoryComboBox
        {
            get { return _CategoryComboBox; }
            set { _CategoryComboBox = value; OnPropertyChanged(CategoryComboBox); }
        }
        private string _RemarksTextBox;

        public override string RemarksTextBox
        {
            get { return _RemarksTextBox; }
            set { _RemarksTextBox = value; OnPropertyChanged(RemarksTextBox); }
        }

        private string _SelectItem;

        public string SelectItem
        {
            get { return _SelectItem; }
            set { _SelectItem = value; OnPropertyChanged(SelectItem); }
        }

        public ObservableCollection<string> Categorys { get; private set; } = CategoryModel.Categorys;

        public VendorInfoRegisterViewModel(MainWindow mainWindow, VendorInfoRegisterWindow vendorInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.vendorInfoRegisterWindow = vendorInfoRegisterWindow;
        }

        public VendorInfoRegisterViewModel(VendorInfoTable vendorInfoTable, MainWindow mainWindow, VendorInfoRegisterWindow vendorInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.vendorInfoRegisterWindow = vendorInfoRegisterWindow;

            InfoRegister = new RelayCommand(InfoUpdateExecute, CanExecute);

            this.vendorInfoTable = vendorInfoTable;
            VendorCodeTextBox = vendorInfoTable.VendorCode;
            VendorNameTextBox = vendorInfoTable.VendorName;
            ModelNumberTextBox = vendorInfoTable.ModelNumber;
            SelectItem = vendorInfoTable.Category;
            RemarksTextBox = vendorInfoTable.Remarks;
        }

        public override bool CanExecute(object sender)
        {
            return true;
        }

        public override void InfoRegisterExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                RegisterValidationCheck();

                text_Info = getRegisterTextInfo(nowString);

                text = "\n\n" +
                    "上記の情報で登録します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "",MessageBoxButton.YesNo);
                if(result == MessageBoxResult.Yes)
                {

                    WebApiClient.CreateTableData(EnumViewModel.Vendor, new VendorInfoTable(
                        VendorCodeTextBox.ToUpper(),
                        VendorNameTextBox,
                        ModelNumberTextBox,
                        SelectItem,
                        nowString,
                        nowString,
                        RemarksTextBox
                        ));

                    text = "\n\n" +
                    "上記の情報を登録しました。";
                    MessageBox.Show(text_Info + text);
                }

                vendorInfoWindow = FactryWindows.GetVendorInfoWindow(mainWindow);
                vendorInfoWindow.Show();
                vendorInfoRegisterWindow.Close();
            }
            catch (ValidationCheckException e)
            {
                MessageBox.Show(e.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public override void InfoUpdateExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                UpdateValidationCheck();

                text_Info = getUpdateTextInfo(nowString);

                text = "\n\n" +
                    "上記の情報で更新します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {

                    WebApiClient.UpdateTableData(EnumViewModel.Vendor, vendorInfoTable.VendorCode, new VendorInfoTable(
                        vendorInfoTable.VendorCode,
                        VendorNameTextBox,
                        ModelNumberTextBox,
                        SelectItem,
                        vendorInfoTable.RegisterDateTime,
                        nowString,
                        RemarksTextBox
                        ));

                    text = "\n\n" +
                    "上記の情報を更新しました。";
                    MessageBox.Show(text_Info + text);
                }

                vendorInfoWindow = FactryWindows.GetVendorInfoWindow(mainWindow);
                vendorInfoWindow.Show();
                vendorInfoRegisterWindow.Close();
            }
            catch (ValidationCheckException e)
            {
                MessageBox.Show(e.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public override void ToMainViewWinodowExecute(object sender)
        {
            mainWindow.Show();
            vendorInfoRegisterWindow.Close();
        }

        public override void ToInfoWinodowExecute(object sender)
        {
            vendorInfoWindow = FactryWindows.GetVendorInfoWindow(mainWindow);
            vendorInfoWindow.Show();
            vendorInfoRegisterWindow.Close();
        }

        protected override string getRegisterTextInfo(string nowString)
        {
            string RegisterText =
                "ベンダーコード : " + VendorCodeTextBox.ToUpper() + "\n" +
                "　　ベンダー名 : " + VendorNameTextBox + "\n" +
                "　　　機器種別 : " + SelectItem + "\n" +
                "　　　　型　番 : " + ModelNumberTextBox + "\n" +
                "　　　登録日時 : " + nowString + "\n" +
                "　　　更新日時 : " + nowString + "\n" +
                "　　　　備　考 : " + RemarksTextBox + "\n";

            return RegisterText;
        }

        protected override string getUpdateTextInfo(string nowString)
        {
            string UpdateText =
                "ベンダーコード : " + vendorInfoTable.VendorCode + "\n" +
                "　　ベンダー名 : " + VendorNameTextBox + "\n" +
                "　　　機器種別 : " + SelectItem + "\n" +
                "　　　　型　番 : " + ModelNumberTextBox + "\n" +
                "　　　登録日時 : " + vendorInfoTable.RegisterDateTime + "\n" +
                "　　　更新日時 : " + nowString + "\n" +
                "　　　　備　考 : " + RemarksTextBox + "\n";

            return UpdateText;
        }

        protected override void setCollectionClear()
        {
            throw new NotImplementedException();
        }

        protected override void RegisterValidationCheck()
        {

            // null check
            if (VendorCodeTextBox == null || VendorCodeTextBox == "")
            {
                throw new ValidationCheckException("【ベンダーコード】未入力です。");
            }

            if (VendorNameTextBox == null || VendorNameTextBox == "")
            {
                throw new ValidationCheckException("【ベンダー名】未入力です。");
            }

            if (SelectItem == null)
            {
                throw new ValidationCheckException("【機器種別名】未選択です。");
            }

            // 文字数チェック
            if (!StaticRegisterValidationCheck.Is_X_Characters(6, VendorCodeTextBox.Length))
            {
                throw new ValidationCheckException("【ベンダーコード】入力文字数が適切ではありません。");
            }

            // 英数字チェック
            if (!StaticRegisterValidationCheck.IsOnlyAlphanumeric(VendorCodeTextBox))
            {
                throw new ValidationCheckException("【ベンダーコード】半角英数字で入力して下さい。");
            }

            foreach (var val in VendorInfoViewModel.InfoTables)
            {
                if (val.VendorCode == VendorCodeTextBox)
                { 
                    throw new ValidationCheckException("【ベンダーコード】重複しています。");
                }
            }

            if (VendorNameTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, VendorNameTextBox.Length))
                {
                    throw new ValidationCheckException("【ベンダー名】入力文字数が適切ではありません。");
                }
            }

            if (ModelNumberTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, ModelNumberTextBox.Length))
                {
                    throw new ValidationCheckException("【型番】入力文字数が適切ではありません。");
                }
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }

        }

        protected override void UpdateValidationCheck()
        {

            if (VendorNameTextBox == null || VendorNameTextBox == "")
            {
                throw new ValidationCheckException("【ベンダー名】未入力です。");
            }

            if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, VendorNameTextBox.Length))
            {
                throw new ValidationCheckException("【ベンダー名】入力文字数が適切ではありません。");
            }

            if (ModelNumberTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, ModelNumberTextBox.Length))
                {
                    throw new ValidationCheckException("【型番】入力文字数が適切ではありません。");
                }
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }

            if (SelectItem == null)
            {
                throw new ValidationCheckException("【機器種別名】未選択です。");
            }
        }
    }
}
