﻿using Microsoft.Win32;
using Microsoft.WindowsAPICodePack.Dialogs;
using NetworkManagementApp.Models;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;


namespace NetworkManagementApp.ViewModels
{
    public class PlaceInfoViewModel : Base_InfoViewModel
    {

        private PlaceInfoWindow placeInfoWindow { get; set; }

        private PlaceInfoTable _SelectedInfoTable;

        public PlaceInfoTable SelectedInfoTable
        {
            get { return _SelectedInfoTable; }
            set { _SelectedInfoTable = value; }
        }

        private string _InfoTablesCount;
        public override string InfoTablesCount
        {
            get { return _InfoTablesCount; }
            set
            {
                _InfoTablesCount = value;
                OnPropertyChanged(nameof(InfoTablesCount));
            }
        }
        

        public static ObservableCollection<PlaceInfoTable> InfoTables { get; set; } = new ObservableCollection<PlaceInfoTable>();

        public PlaceInfoViewModel(MainWindow mainWindow, PlaceInfoWindow placeInfoWindow)
        {
            this.mainWindow = mainWindow;
            this.placeInfoWindow = placeInfoWindow;
        }

        private string place;
        private string remarks;

        public override void ShowBulkRegisterWindowExecute(object sender)
        {
            // ダイアログのインスタンスを生成
            var dialog = new OpenFileDialog();

            // ファイルの種類を設定
            dialog.Filter = "tsvファイル (*.tsv)|*.tsv";

            // ダイアログを表示する
            if (dialog.ShowDialog() == true)
            {
                // 選択されたファイル名 (ファイルパス) をメッセージボックスに表示
                using (FileStream fs = new FileStream(dialog.FileName, FileMode.Open))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        try
                        {
                            string line;
                            int lineCount = 0;
                            string[] lineSplit;

                            //

                            string[] DataArray = new string[2];
                            List<string[]> DataList = new List<string[]>();

                            while ((line = sr.ReadLine()) != null)
                            {
                                if (lineCount == 0) 
                                {
                                    lineCount++;
                                    continue;
                                }
                                lineSplit = line.Split('\t');

                                //
                                place = lineSplit[0];
                                remarks = lineSplit[1];

                                BulkRegisterValidationCheck();

                                //
                                DataArray = new string[2] { place , remarks };
                                DataList.Add(DataArray);

                                lineCount++;
                            }

                            lineCount -= 1;

                            string text =
                                $"{lineCount} 件を一括登録します。\n" +
                                $"\n" +
                                $"よろしいですか？";

                            MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                            if (result == MessageBoxResult.Yes)
                            {

                                foreach (string[] array in DataList) 
                                {
                                    place = array[0];
                                    remarks = array[1];

                                    string nowString = DateTime.Now.ToString();

                                    WebApiClient.CreateTableData(EnumViewModel.Place, new PlaceInfoTable(place,nowString,nowString,remarks));

                                }
                                SetTables();
                                SetTablesCount();
                                MessageBox.Show($"{lineCount} 件を一括登録しました。");
                                DataList.Clear();
                            }
                        }
                        catch (ValidationCheckException e)
                        {
                            MessageBox.Show(e.Message);
                        }
                        catch (Exception e)
                        {
                            MessageBox.Show(e.Message);
                        }
                    }
                }
            }
        }

        public override void DeleteCommandExecute(object sender)
        {
            if(SelectedInfoTable.PlaceInfoId == -1)
            {
                MessageBox.Show("行が選択されていません。");
            }
            else
            {
                int id = SelectedInfoTable.PlaceInfoId;
                string text = $"設置場所Id : {id} を削除します。\n\nよろしいですか？";

                MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    WebApiClient.DeleteTableData(EnumViewModel.Place, id.ToString());

                    SetTables();
                    MessageBox.Show($"設置場所Id : {id} を削除しました。");
                }
            }
        }

        public override void UpdateCommandExecute(object sender)
        {
            if (SelectedInfoTable.PlaceInfoId == -1)
            {
                MessageBox.Show("行が選択されていません。");
            }
            else
            {
                PlaceInfoRegisterWindow placeInfoUpdateWindow = FactryWindows.GetPlaceInfoUpdateWindow(true,mainWindow, SelectedInfoTable);
                placeInfoUpdateWindow.Show();
                placeInfoWindow.Close();
            }
        }

        public override void AllDeleteCommandExecute(object sender)
        {
            MessageBoxResult result = MessageBox.Show("すべての登録情報を削除します。\n\nよろしいですか？", "",MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                WebApiClient.DeleteAllTableData(EnumViewModel.Place);

                ClearTables();
                SetTablesCount();
                MessageBox.Show("すべての登録情報を削除しました。");
            }
        }

        public override void ShowInfoRegisterWindowExecute(object sender)
        {
            PlaceInfoRegisterWindow placeInfoRegisterWindow = FactryWindows.GetPlaceInfoRegisterWindow(mainWindow);
            placeInfoRegisterWindow.Show();
            placeInfoWindow.Close();
        }

        protected override async void SetTables()
        {
            ClearTables();
            WebApiClient.ReadTableData(EnumViewModel.Place);
            await Task.Delay(100);
            SetTablesCount();

            SelectedInfoTable = new PlaceInfoTable() { PlaceInfoId = -1 };
        }

        protected override void ClearTables()
        {
            if (InfoTables.Count >= 1)
            {
                for (int i = InfoTables.Count - 1; i >= 0; i--)
                {
                    InfoTables.RemoveAt(i);
                }
            }
        }
        protected override void SetTablesCount()
        {
            string placeInfoTablesCount = InfoTables.Count.ToString();
            string text = $"表示件数：　{placeInfoTablesCount}　件";
            InfoTablesCount = text;
        }

        public override void ToMainViewWinodowExecute(object sender)
        {
            mainWindow.Show();
            ClearTables();
            placeInfoWindow.Close();
        }

        public override bool CanExecute(object sender)
        {
            return true;
        }

        protected override void BulkRegisterValidationCheck()
        {
            if (place != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, place.Length))
                {
                    throw new ValidationCheckException("【設置場所】入力文字数が適切ではありません。");
                }
            }

            foreach (var val in InfoTables)
            {
                if (val.Place == place)
                {
                    throw new ValidationCheckException("【設置場所】重複しています。");
                }
            }

            if (remarks != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, remarks.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }

        public override void OutputAllDataCommandExecute(object sender)
        {
            //throw new NotImplementedException();
            MessageBox.Show("出力先フォルダを選択してください。");

            // データ出力
            using (CommonOpenFileDialog cofd = new CommonOpenFileDialog())
            {
                // フォルダを選択できるようにする
                cofd.IsFolderPicker = true;

                if (cofd.ShowDialog() == CommonFileDialogResult.Ok)
                {
                    //MessageBox.Show($"{cofd.FileName}");

                    using (FileStream fs = new FileStream($"{cofd.FileName}" + "\\設置場所データ出力結果_" + $"{DateTime.Now.ToString("yyyy.MM.dd")}" + ".tsv", FileMode.Create,FileAccess.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(fs))
                        {
                            try
                            {
                                sw.WriteLine("設置場所id\t設置場所\t登録日時\t更新日時\t備考");
                                foreach (PlaceInfoTable InfoTable in InfoTables)
                                {
                                    sw.WriteLine($"{InfoTable.PlaceInfoId}\t{InfoTable.Place}\t{InfoTable.RegisterDateTime}\t{InfoTable.UpdateDateTime}\t{InfoTable.Remarks}");
                                }
                            }
                            catch (Exception e)
                            {
                                MessageBox.Show(e.Message);
                            }
                        }
                    }
                }
            }
        }
    }
}
