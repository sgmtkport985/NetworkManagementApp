﻿using NetworkManagementApp.Models;
using NetworkManagementApp.MVVM;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class MacMonitorInfoRegisterViewModel : Base_InfoRegisterViewModel
    {
        private MacMonitorInfoRegisterWindow macMonitorInfoRegisterWindow;
        private MacMonitorInfoWindow macMonitorInfoWindow;
        private MacMonitorInfoTable macMonitorInfoTable;

        public static Dictionary<string, int> MacAddressDictionary { get; set; } = new Dictionary<string, int>();

        private string macAddressTextBox;
        public string MacAddressTextBox
        {
            get { return macAddressTextBox; }
            set { macAddressTextBox = value; OnPropertyChanged(MacAddressTextBox); }
        }

        public MacMonitorInfoRegisterViewModel(MainWindow mainWindow, MacMonitorInfoRegisterWindow macMonitorInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.macMonitorInfoRegisterWindow = macMonitorInfoRegisterWindow;
        }

        public MacMonitorInfoRegisterViewModel(MacMonitorInfoTable macMonitorInfoTable, MainWindow mainWindow, MacMonitorInfoRegisterWindow macMonitorInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.macMonitorInfoRegisterWindow = macMonitorInfoRegisterWindow;
            this.macMonitorInfoWindow = FactryWindows.GetMacMonitorInfoWindow(mainWindow);
            InfoRegister = new RelayCommand(InfoUpdateExecute, CanExecute);

            this.macMonitorInfoTable = macMonitorInfoTable;
            MacAddressTextBox = macMonitorInfoTable.MACAddress;
            RemarksTextBox = macMonitorInfoTable.Remarks;
        }

        public override bool CanExecute(object sender)
        {
            return true;
        }

        public override void InfoRegisterExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                RegisterValidationCheck();

                text_Info = getRegisterTextInfo(nowString);

                text =
                    "\n\n" +
                    "上記の情報を登録します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    WebApiClient.CreateTableData(EnumViewModel.MacMonitor,new MacMonitorInfoTable(MacAddressTextBox, nowString, nowString, RemarksTextBox));

                    text =
                    "\n\n" +
                    "上記の情報を登録しました。";
                    MessageBox.Show(text_Info + text);
                }

                setCollectionClear();

                macMonitorInfoWindow = FactryWindows.GetMacMonitorInfoWindow(mainWindow);
                macMonitorInfoWindow.Show();
                macMonitorInfoRegisterWindow.Close();
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public override void InfoUpdateExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                UpdateValidationCheck();

                text_Info = getUpdateTextInfo(nowString);

                text = "\n\n" +
                    "上記の情報で更新します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {

                    WebApiClient.UpdateTableData(EnumViewModel.MacMonitor,macMonitorInfoTable.MacMonitorInfoId.ToString(),
                        (InfoTable)new MacMonitorInfoTable(
                            macMonitorInfoTable.MacMonitorInfoId,
                            macAddressTextBox,
                            macMonitorInfoTable.RegisterDateTime,
                            nowString,
                            RemarksTextBox
                        ));

                    text = "\n\n" +
                    "上記の情報で更新しました。";

                    MessageBox.Show(text_Info + text);

                    macMonitorInfoWindow = FactryWindows.GetMacMonitorInfoWindow(mainWindow);
                    macMonitorInfoWindow.Show();
                    macMonitorInfoRegisterWindow.Close();
                }
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public override void ToInfoWinodowExecute(object sender)
        {
            setCollectionClear();
            macMonitorInfoWindow = FactryWindows.GetMacMonitorInfoWindow(mainWindow);
            macMonitorInfoWindow.Show();
            macMonitorInfoRegisterWindow.Close();
        }

        public override void ToMainViewWinodowExecute(object sender)
        {
            setCollectionClear();
            mainWindow.Show();
            macMonitorInfoRegisterWindow.Close();
        }

        protected override string getRegisterTextInfo(string nowString)
        {
            string RegisterText =
                "IPアドレス 　: " + MacAddressTextBox + "\n" +
                "登録日時 　: " + nowString + "\n" +
                "更新日時 　: " + nowString + "\n" +
                "　備　考 　: " + RemarksTextBox;

            return RegisterText;
        }

        protected override string getUpdateTextInfo(string nowString)
        {
            string UpdateText =
                "MAC監視id : " + macMonitorInfoTable.MacMonitorInfoId.ToString() + "\n" +
                "MACアドレス 　: " + MacAddressTextBox + "\n" +
                "登録日時 　: " + macMonitorInfoTable.RegisterDateTime + "\n" +
                "更新日時 　: " + nowString + "\n" +
                "　備　考 　: " + RemarksTextBox;

            return UpdateText;
        }

        protected override void RegisterValidationCheck()
        {
            // null check
            if (MacAddressTextBox == null || MacAddressTextBox == "")
            {
                throw new ValidationCheckException("【MACアドレス】未入力です。");
            }

            if (!StaticRegisterValidationCheck.IsWithin_X_Characters(14, MacAddressTextBox.Length))
            {
                throw new ValidationCheckException("【MACアドレス】入力文字数が適切ではありません。");
            }

            foreach (var val in MacMonitorInfoViewModel.InfoTables)
            {
                if (val.MACAddress == macAddressTextBox)
                {
                    throw new ValidationCheckException("【MACアドレス】重複しています。");
                }
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }

        protected override void setCollectionClear()
        {
            MacAddressDictionary.Clear();
        }

        protected override void UpdateValidationCheck()
        {
            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }
    }
}
