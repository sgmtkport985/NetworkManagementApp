﻿using NetworkManagementApp.Models;
using NetworkManagementApp.MVVM;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class IpMonitorInfoRegisterViewModel : Base_InfoRegisterViewModel
    {
        public static Dictionary<string, int> IpAddressDictionary { get; set; } = new Dictionary<string, int>();

        private string ipAddressTextBox;
        public string IpAddressTextBox
        {
            get { return ipAddressTextBox; }
            set { ipAddressTextBox = value; OnPropertyChanged(IpAddressTextBox); }
        }

        private IpMonitorInfoRegisterWindow ipMonitorInfoRegisterWindow;
        private IpMonitorInfoWindow ipMonitorInfoWindow;
        private IpMonitorInfoTable ipMonitorInfoTable;

        public IpMonitorInfoRegisterViewModel(MainWindow mainWindow, IpMonitorInfoRegisterWindow ipMonitorInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.ipMonitorInfoRegisterWindow = ipMonitorInfoRegisterWindow;
        }
        public IpMonitorInfoRegisterViewModel(IpMonitorInfoTable ipMonitorInfoTable, MainWindow mainWindow, IpMonitorInfoRegisterWindow ipMonitorInfoRegisterWindow)
        {
            this.mainWindow = mainWindow;
            this.ipMonitorInfoRegisterWindow = ipMonitorInfoRegisterWindow;
            this.ipMonitorInfoWindow = FactryWindows.GetIpMonitorInfoWindow(mainWindow);
            InfoRegister = new RelayCommand(InfoUpdateExecute, CanExecute);

            this.ipMonitorInfoTable = ipMonitorInfoTable;
            IpAddressTextBox = ipMonitorInfoTable.IPAddress;
            RemarksTextBox = ipMonitorInfoTable.Remarks;
        }

        public override void InfoRegisterExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                RegisterValidationCheck();

                text_Info = getRegisterTextInfo(nowString);

                text =
                    "\n\n" +
                    "上記の情報を登録します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    WebApiClient.CreateTableData(EnumViewModel.IpMonitor,new IpMonitorInfoTable(IpAddressTextBox, nowString, nowString, RemarksTextBox));

                    text =
                    "\n\n" +
                    "上記の情報を登録しました。";
                    MessageBox.Show(text_Info + text);
                }

                setCollectionClear();

                ipMonitorInfoWindow = FactryWindows.GetIpMonitorInfoWindow(mainWindow);
                ipMonitorInfoWindow.Show();
                ipMonitorInfoRegisterWindow.Close();
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public override void InfoUpdateExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                UpdateValidationCheck();

                text_Info = getUpdateTextInfo(nowString);

                text = "\n\n" +
                    "上記の情報で更新します。\n" +
                    "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    WebApiClient.UpdateTableData(EnumViewModel.IpMonitor,ipMonitorInfoTable.IpMonitorInfoId.ToString(),new IpMonitorInfoTable(ipMonitorInfoTable.IpMonitorInfoId, ipAddressTextBox, ipMonitorInfoTable.RegisterDateTime,nowString, RemarksTextBox));

                    text = "\n\n" +
                    "上記の情報で更新しました。";

                    MessageBox.Show(text_Info + text);

                    ipMonitorInfoWindow = FactryWindows.GetIpMonitorInfoWindow(mainWindow);
                    ipMonitorInfoWindow.Show();
                    ipMonitorInfoRegisterWindow.Close();
                }
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public override void ToInfoWinodowExecute(object sender)
        {
            setCollectionClear();
            ipMonitorInfoWindow = FactryWindows.GetIpMonitorInfoWindow(mainWindow);
            ipMonitorInfoWindow.Show();
            ipMonitorInfoRegisterWindow.Close();
        }
        public override void ToMainViewWinodowExecute(object sender)
        {
            setCollectionClear();
            mainWindow.Show();
            ipMonitorInfoRegisterWindow.Close();
        }

        protected override string getRegisterTextInfo(string nowString)
        {
            string RegisterText =
                "IPアドレス 　: " + IpAddressTextBox + "\n" +
                "登録日時 　: " + nowString + "\n" +
                "更新日時 　: " + nowString + "\n" +
                "　備　考 　: " + RemarksTextBox;

            return RegisterText;
        }
        protected override string getUpdateTextInfo(string nowString)
        {
            string UpdateText =
                "IP監視id : " + ipMonitorInfoTable.IpMonitorInfoId.ToString() + "\n" +
                "IPアドレス 　: " + IpAddressTextBox + "\n" +
                "登録日時 　: " + ipMonitorInfoTable.RegisterDateTime + "\n" +
                "更新日時 　: " + nowString + "\n" +
                "　備　考 　: " + RemarksTextBox;

            return UpdateText;
        }
        protected override void RegisterValidationCheck()
        {
            // null check
            if (IpAddressTextBox == null || IpAddressTextBox == "")
            {
                throw new ValidationCheckException("【IPアドレス】未入力です。");
            }

            if (!StaticRegisterValidationCheck.IsWithin_X_Characters(15, IpAddressTextBox.Length))
            {
                throw new ValidationCheckException("【IPアドレス】入力文字数が適切ではありません。");
            }

            foreach (var val in IpMonitorInfoViewModel.InfoTables)
            {
                if (val.IPAddress == IpAddressTextBox)
                { 
                    throw new ValidationCheckException("【IPアドレス】重複しています。");
                }
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }
        protected override void setCollectionClear()
        {
            IpAddressDictionary.Clear();
        }
        protected override void UpdateValidationCheck()
        {
            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }
    }
}
