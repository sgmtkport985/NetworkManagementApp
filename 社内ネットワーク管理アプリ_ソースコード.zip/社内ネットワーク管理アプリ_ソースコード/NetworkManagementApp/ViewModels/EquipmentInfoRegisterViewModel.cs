﻿using NetworkManagementApp.Models;
using NetworkManagementApp.MVVM;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class EquipmentInfoRegisterViewModel : Base_InfoRegisterViewModel
    {
        public static ObservableCollection<string> Place { get; set; } = new ObservableCollection<string>();
        public static Dictionary<string, int> PlaceDictionary { get; set; } = new Dictionary<string, int>();

        public string VendorCode { get; set; }

        private EquipmentInfoWindow EquipmentInfoWindow { get; set; }
        private EquipmentInfoRegisterWindow EquipmentInfoRegisterScreenWindow { get; set; }
        private EquipmentInfoTable EquipmentInfoTable { get; set; }

        private Dictionary<string, string> DictionaryVendorCodeVendorName { get; set; } = new Dictionary<string, string>();
        private Dictionary<string, string> DictionaryVendorCodeCategory { get; set; } = new Dictionary<string, string>();


        #region OnPropertyChanged Property

            private string _MACAddressTextBox;
            public string MACAddressTextBox
            {
                get { return _MACAddressTextBox; }
                set { _MACAddressTextBox = value; OnPropertyChanged(MACAddressTextBox); }
            }

            private string _VendorNameTextBox;
            public string VendorNameTextBox
            {
                get { return _VendorNameTextBox; }
                set { _VendorNameTextBox = value; OnPropertyChanged(VendorNameTextBox); }
            }

            private string _IPAddressTextBox;
            public string IPAddressTextBox
            {
                get { return _IPAddressTextBox; }
                set { _IPAddressTextBox = value; OnPropertyChanged(IPAddressTextBox); }
            }

            private string _HostNameTextBox;
            public string HostNameTextBox
            {
                get { return _HostNameTextBox; }
                set { _HostNameTextBox = value; OnPropertyChanged(HostNameTextBox); }
            }

            private string _ModelNumberTextBox;
            public string ModelNumberTextBox
            {
                get { return _ModelNumberTextBox; }
                set { _ModelNumberTextBox = value; OnPropertyChanged(ModelNumberTextBox); }
            }

            private string _SelectItem;
            public string SelectItem
            {
                get { return _SelectItem; }
                set { _SelectItem = value; OnPropertyChanged(SelectItem); }
            }

        #endregion

        public EquipmentInfoRegisterViewModel(MainWindow mainWindow, EquipmentInfoRegisterWindow equipmentInfoRegisterScreenWindow)
        {
            this.mainWindow = mainWindow;
            this.EquipmentInfoRegisterScreenWindow = equipmentInfoRegisterScreenWindow;

            ReadPlace();
            MakeDictionaryVendorNameCategory();
        }

        public EquipmentInfoRegisterViewModel(EquipmentInfoTable equipmentInfoTable, MainWindow mainWindow, EquipmentInfoRegisterWindow equipmentInfoRegisterScreenWindow)
        {
            this.mainWindow = mainWindow;
            this.EquipmentInfoRegisterScreenWindow = equipmentInfoRegisterScreenWindow;

            InfoRegister = new RelayCommand(InfoUpdateExecute, CanExecute);

            this.EquipmentInfoTable = equipmentInfoTable;

            MACAddressTextBox = equipmentInfoTable.MacAddress;
            IPAddressTextBox = equipmentInfoTable.IpAddress;
            HostNameTextBox = equipmentInfoTable.HostName;
            SelectItem = equipmentInfoTable.Place;
            RemarksTextBox = equipmentInfoTable.Remarks;

            ReadPlace();
            MakeDictionaryVendorNameCategory();
        }

        public override bool CanExecute(object sender)
        {
            return true;
        }

        public override void InfoRegisterExecute(object sender)
        {
            try
            { 
                nowString = DateTime.Now.ToString();

                RegisterValidationCheck();

                text_Info = getRegisterTextInfo(nowString);

                text =
                "\n\n" +
                "上記の情報を登録します。\n" +
                "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    VendorCode = GetVendorCode(MACAddressTextBox);

                    WebApiClient.CreateTableData(EnumViewModel.Equipment, new EquipmentInfoTable(
                        MACAddressTextBox,
                        IPAddressTextBox,
                        HostNameTextBox,
                        GetVendorName(VendorCode),
                        GetCategory(VendorCode),
                        SelectItem,
                        nowString,
                        nowString,
                        RemarksTextBox
                        ));

                    text =
                    "\n\n" +
                    "上記の情報を登録しました。";
                    MessageBox.Show(text_Info + text);
                }

                MACAddressTextBox = null;
                IPAddressTextBox = null;
                HostNameTextBox = null;
                SelectItem = null;
                RemarksTextBox = null;

                EquipmentInfoWindow = FactryWindows.GetEquipmentInfoWindow(mainWindow);
                EquipmentInfoWindow.Show();
                EquipmentInfoRegisterScreenWindow.Close();            
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public override void ToMainViewWinodowExecute(object sender)
        {
            setCollectionClear();

            mainWindow.Show();
            EquipmentInfoRegisterScreenWindow.Close();
        }

        public override void ToInfoWinodowExecute(object sender)
        {
            setCollectionClear();

            EquipmentInfoWindow = FactryWindows.GetEquipmentInfoWindow(mainWindow);
            EquipmentInfoWindow.Show();
            EquipmentInfoRegisterScreenWindow.Close();
        }

        public override void InfoUpdateExecute(object sender)
        {
            try
            {
                nowString = DateTime.Now.ToString();

                UpdateValidationCheck();

                text_Info = getUpdateTextInfo(nowString);

                text =
                "\n\n" +
                "上記の情報を更新します。\n" +
                "よろしいですか？";

                MessageBoxResult result = MessageBox.Show(text_Info + text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    VendorCode = GetVendorCode(EquipmentInfoTable.MacAddress);

                    WebApiClient.UpdateTableData(EnumViewModel.Equipment, EquipmentInfoTable.EquipmentInfoId.ToString(), new EquipmentInfoTable(
                        EquipmentInfoTable.EquipmentInfoId.ToString(),
                        EquipmentInfoTable.MacAddress,
                        IPAddressTextBox,
                        HostNameTextBox,
                        GetVendorName(VendorCode),
                        GetCategory(VendorCode),
                        EquipmentInfoTable.RegisterDateTime,
                        nowString,
                        RemarksTextBox
                        ));

                    text =
                    "\n\n" +
                    "上記の情報を更新しました。";
                    MessageBox.Show(text_Info + text);
                }

                IPAddressTextBox = null;
                HostNameTextBox = null;
                SelectItem = null;
                RemarksTextBox = null;

                EquipmentInfoWindow = FactryWindows.GetEquipmentInfoWindow(mainWindow);
                EquipmentInfoWindow.Show();
                EquipmentInfoRegisterScreenWindow.Close();
            }
            catch (ValidationCheckException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        protected override void setCollectionClear()
        {
            Place.Clear();
            PlaceDictionary.Clear();
        }

        protected override string getRegisterTextInfo(string nowString)
        {
            string RegisterText =
                "MACアドレス : " + MACAddressTextBox + "\n" +
                "IPアドレス : " + IPAddressTextBox + "\n" +
                "ホスト名 : " + HostNameTextBox + "\n" +
                "設置場所 : " + SelectItem + "\n" +
                "登録日時 : " + nowString + "\n" +
                "更新日時 : " + nowString + "\n" +
                "　備　考 : " + RemarksTextBox + "\n";

            return RegisterText;
        }

        protected override string getUpdateTextInfo(string nowString)
        {
            string UpdateText =
                "MACアドレス : " + EquipmentInfoTable.MacAddress + "\n" +
                "IPアドレス : " + IPAddressTextBox + "\n" +
                "ホスト名 : " + HostNameTextBox + "\n" +
                "設置場所 : " + SelectItem + "\n" +
                "登録日時 : " + EquipmentInfoTable.RegisterDateTime + "\n" +
                "更新日時 : " + nowString + "\n" +
                "　備　考 : " + RemarksTextBox + "\n";

            return UpdateText;
        }

        protected override async void RegisterValidationCheck()
        {
            if (MACAddressTextBox == null || MACAddressTextBox == "")
            {
                throw new ValidationCheckException("【MACアドレス】未入力です。");
            }

            WebApiClient.ReadTableData(EnumViewModel.Equipment);
            await Task.Delay(100);
            foreach (var val in EquipmentInfoViewModel.InfoTables)
            {
                if (val.MacAddress == MACAddressTextBox)
                {
                    throw new ValidationCheckException($"【MACアドレス】重複しています。\n\n{MACAddressTextBox}");
                }
            }

            if (IPAddressTextBox == null || IPAddressTextBox == "")
            {
                throw new ValidationCheckException("【IPアドレス】未入力です。");
            }

            if (SelectItem == null)
            {
                throw new ValidationCheckException("【設置場所】未選択です。");
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }

        protected override void UpdateValidationCheck()
        {
            if (IPAddressTextBox == null || IPAddressTextBox == "")
            {
                throw new ValidationCheckException("【IPアドレス】未入力です。");
            }

            if (SelectItem == null)
            {
                throw new ValidationCheckException("【設置場所】未選択です。");
            }

            if (RemarksTextBox != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, RemarksTextBox.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }
        private async void ReadPlace()
        {
            WebApiClient.ReadTableData(EnumViewModel.Place);
            await Task.Delay(100);
            Place.Clear();
            foreach (var val in PlaceInfoViewModel.InfoTables)
            {
                Place.Add(val.Place);
            }
        }
        private async void MakeDictionaryVendorNameCategory()
        {
            WebApiClient.ReadTableData(EnumViewModel.Vendor);
            await Task.Delay(100);

            foreach (var val in VendorInfoViewModel.InfoTables)
            {
                DictionaryVendorCodeVendorName[val.VendorCode] = val.VendorName;
                DictionaryVendorCodeCategory[val.VendorCode] = val.Category;
            }
        }

        private string GetVendorName(string VendorCode)
        {
            if (DictionaryVendorCodeVendorName.ContainsKey(VendorCode))
            {
                return DictionaryVendorCodeVendorName[VendorCode];
            }
            return "";
        }
        private string GetCategory(string VendorCode)
        {
            if (DictionaryVendorCodeVendorName.ContainsKey(VendorCode))
            {
                return DictionaryVendorCodeVendorName[VendorCode];
            }
            return "";
        }
        private string GetVendorCode(string MACAddressTextBox)
        {
            string macAddressUpper = MACAddressTextBox.ToUpper();
            string macAddressUpperIsDot;
            string vendorCode = "";

            if (macAddressUpper.Contains('-'))
            {
                macAddressUpperIsDot = macAddressUpper.Replace('-', '.');
            }
            else if (macAddressUpper.Contains(';'))
            { 
                macAddressUpperIsDot = macAddressUpper.Replace(';', '.');
            }
            else
            {
                macAddressUpperIsDot = macAddressUpper;
            }

            foreach (char c in macAddressUpperIsDot)
            {
                if (c != '.')
                {
                    vendorCode += c;
                }
            }

            return vendorCode.Substring(0, 6);
        }

    }
}
