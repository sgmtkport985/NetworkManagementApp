﻿using Microsoft.Win32;
using Microsoft.WindowsAPICodePack.Dialogs;
using NetworkManagementApp.Models;
using NetworkManagementApp.ViewModels.Util;
using NetworkManagementApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using static NetworkManagementApp.ViewModels.Util.WebApiClient;

namespace NetworkManagementApp.ViewModels
{
    public class IpMonitorInfoViewModel : Base_InfoViewModel
    {
        public static ObservableCollection<IpMonitorInfoTable> InfoTables { get; set; } = new ObservableCollection<IpMonitorInfoTable>();

        public MainViewModel MainViewModel { get; private set; }

        private IpMonitorInfoTable _SelectedInfoTable;
        public IpMonitorInfoTable SelectedInfoTable
        {
            get { return _SelectedInfoTable; }
            set { _SelectedInfoTable = value; }
        }

        private IpMonitorInfoWindow IpMonitorInfoWindow { get; set; }

        private string _InfoTablesCount;
        public override string InfoTablesCount
        {
            get { return _InfoTablesCount; }
            set
            {
                _InfoTablesCount = value;
                OnPropertyChanged(nameof(InfoTablesCount));
            }
        }

        private string ipAddress;
        private string remarks;

        public IpMonitorInfoViewModel(MainWindow mainWindow, IpMonitorInfoWindow ipMonitorInfoWindow)
        {
            this.mainWindow = mainWindow;
            this.IpMonitorInfoWindow = ipMonitorInfoWindow;
        }
        public IpMonitorInfoViewModel(MainWindow mainWindow, MainViewModel MainViewModel, IpMonitorInfoWindow ipMonitorInfoWindow)
        {
            this.MainViewModel = MainViewModel;
            this.mainWindow = mainWindow;
            this.IpMonitorInfoWindow = ipMonitorInfoWindow;
        }

        public override void AllDeleteCommandExecute(object sender)
        {
            MessageBoxResult result = MessageBox.Show("すべての登録情報を削除します。\n\nよろしいですか？", "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                WebApiClient.DeleteAllTableData(EnumViewModel.IpMonitor);

                ClearTables();
                SetTablesCount();
                IpMonitorInfoRegisterViewModel.IpAddressDictionary.Clear();

                MessageBox.Show("すべての登録情報を削除しました。");
            }
        }
        public override void DeleteCommandExecute(object sender)
        {
            if (SelectedInfoTable.IpMonitorInfoId == -1)
            {
                MessageBox.Show("行が選択されていません。");
            }
            else
            {
                int id = SelectedInfoTable.IpMonitorInfoId;
                string text = $"IP監視id : {id} を削除します。\n\nよろしいですか？";

                MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    WebApiClient.DeleteTableData(EnumViewModel.IpMonitor,id.ToString());

                    SetTables();
                    MessageBox.Show($"IP監視id : {id} を削除しました。");
                }
            }
        }
        public override void ShowBulkRegisterWindowExecute(object sender)
        {
            // ダイアログのインスタンスを生成
            var dialog = new OpenFileDialog();

            // ファイルの種類を設定
            dialog.Filter = "tsvファイル (*.tsv)|*.tsv";

            // ダイアログを表示する
            if (dialog.ShowDialog() == true)
            {
                // 選択されたファイル名 (ファイルパス) をメッセージボックスに表示
                using (FileStream fs = new FileStream(dialog.FileName, FileMode.Open))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        try
                        {
                            string line;
                            int lineCount = 0;
                            string[] lineSplit;

                            //

                            string[] DataArray = new string[2];
                            List<string[]> DataList = new List<string[]>();

                            while ((line = sr.ReadLine()) != null)
                            {
                                if (lineCount == 0)
                                {
                                    lineCount++;
                                    continue;
                                }
                                lineSplit = line.Split('\t');

                                //
                                ipAddress = lineSplit[0];
                                remarks = lineSplit[1];

                                BulkRegisterValidationCheck();



                                //
                                DataArray = new string[2] { ipAddress, remarks };
                                DataList.Add(DataArray);

                                lineCount++;
                            }

                            lineCount -= 1;

                            string text =
                                $"{lineCount} 件を一括登録します。\n" +
                                $"\n" +
                                $"よろしいですか？";

                            MessageBoxResult result = MessageBox.Show(text, "", MessageBoxButton.YesNo);
                            if (result == MessageBoxResult.Yes)
                            {
                                foreach (string[] array in DataList)
                                {
                                    ipAddress = array[0];
                                    remarks = array[1];

                                    string nowString = DateTime.Now.ToString();

                                    WebApiClient.CreateTableData(EnumViewModel.IpMonitor, new IpMonitorInfoTable(ipAddress,nowString,nowString,remarks));
                                }

                                SetTables();
                                SetTablesCount();
                                MessageBox.Show($"{lineCount} 件を一括登録しました。");
                                DataList.Clear();
                            }
                        }
                        catch (ValidationCheckException e)
                        {
                            MessageBox.Show(e.Message);
                        }
                        catch (Exception e)
                        {
                            MessageBox.Show(e.Message);
                        }
                    }
                }
            }
        }
        public override void ShowInfoRegisterWindowExecute(object sender)
        {
            IpMonitorInfoRegisterWindow ipMonitorInfoRegisterWindow = FactryWindows.GetIpMonitorInfoRegisterWindow(mainWindow);
            ipMonitorInfoRegisterWindow.Show();
            IpMonitorInfoWindow.Close();
        }
        public override void ToMainViewWinodowExecute(object sender)
        {
            mainWindow.Show();
            ClearTables();
            IpMonitorInfoWindow.Close();
        }
        public override void UpdateCommandExecute(object sender)
        {
            if (SelectedInfoTable.IpMonitorInfoId == -1)
            {
                throw new Exception("行が選択されていません。");
            }
            else
            {
                IpMonitorInfoRegisterWindow IpMonitorInfoUpdateWindow = FactryWindows.GetIpMonitorInfoUpdateWindow(true, mainWindow, SelectedInfoTable);
                IpMonitorInfoUpdateWindow.Show();
                IpMonitorInfoWindow.Close();
            }
        }
        public override void OutputAllDataCommandExecute(object sender)
        {
            //throw new NotImplementedException();
            MessageBox.Show("出力先フォルダを選択してください。");

            // データ出力
            using (CommonOpenFileDialog cofd = new CommonOpenFileDialog())
            {
                // フォルダを選択できるようにする
                cofd.IsFolderPicker = true;

                if (cofd.ShowDialog() == CommonFileDialogResult.Ok)
                {
                    //MessageBox.Show($"{cofd.FileName}");

                    using (FileStream fs = new FileStream($"{cofd.FileName}" + "\\IP監視データ出力結果_" + $"{DateTime.Now.ToString("yyyy.MM.dd")}" + ".tsv", FileMode.Create, FileAccess.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(fs))
                        {
                            try
                            {
                                sw.WriteLine("IP監視id\tIPアドレス\t登録日時\t更新日時\t備考");
                                foreach (IpMonitorInfoTable InfoTable in InfoTables)
                                {
                                    sw.WriteLine($"{InfoTable.IpMonitorInfoId}\t{InfoTable.IPAddress}\t{InfoTable.RegisterDateTime}\t{InfoTable.UpdateDateTime}\t{InfoTable.Remarks}");
                                }
                            }
                            catch (Exception e)
                            {
                                MessageBox.Show(e.Message);
                            }
                        }
                    }

                }
            }
        }

        protected override async void SetTables()
        {
            ClearTables();

            WebApiClient.ReadTableData(EnumViewModel.IpMonitor);

            await Task.Delay(100);

            SetTablesCount();

            SelectedInfoTable = new IpMonitorInfoTable() { IpMonitorInfoId = -1 };
        }
        protected override void BulkRegisterValidationCheck()
        {
            // null check
            if (ipAddress == null || ipAddress == "")
            {
                throw new ValidationCheckException("【IPアドレス】未入力です。");
            }

            if (!StaticRegisterValidationCheck.IsWithin_X_Characters(15, ipAddress.Length))
            {
                throw new ValidationCheckException("【IPアドレス】入力文字数が適切ではありません。");
            }

            foreach (var val in InfoTables)
            {
                if (val.IPAddress == ipAddress)
                { 
                    throw new ValidationCheckException("【IPアドレス】重複しています。");
                }
            }

            if (remarks != null)
            {
                if (!StaticRegisterValidationCheck.IsWithin_X_Characters(50, remarks.Length))
                {
                    throw new ValidationCheckException("【備考】入力文字数が適切ではありません。");
                }
            }
        }
        protected override void ClearTables()
        {
            if (InfoTables.Count >= 1)
            {
                for (int i = InfoTables.Count - 1; i >= 0; i--)
                {
                    InfoTables.RemoveAt(i);
                }
            }
        }
        protected override void SetTablesCount()
        {
            string tablesCount = InfoTables.Count.ToString();
            string text = $"表示件数：　{tablesCount}　件";
            InfoTablesCount = text;
        }
    }
}
