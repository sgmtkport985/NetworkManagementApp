﻿
namespace NetworkManagementApp.Models
{
    public class InfoTable{}
}
