﻿
namespace NetworkManagementApp.Models
{
    public class VendorInfoTable : InfoTable
    {
        public string VendorCode { get; set; }
        public string VendorName { get; set; }
        public string ModelNumber { get; set; }
        public string Category { get; set; }

        public string RegisterDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public string Remarks { get; set; }

        public VendorInfoTable()
        {

        }

        public VendorInfoTable(string VendorCode, string VendorName, string ModelNumber, string Category, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.VendorCode = VendorCode;
            this.VendorName = VendorName;
            this.ModelNumber = ModelNumber;
            this.Category = Category;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }
    }

}
