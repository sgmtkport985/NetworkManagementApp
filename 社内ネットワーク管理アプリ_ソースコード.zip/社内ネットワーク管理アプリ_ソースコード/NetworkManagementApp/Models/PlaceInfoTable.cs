﻿
namespace NetworkManagementApp.Models
{
    public class PlaceInfoTable : InfoTable
    {
        public int PlaceInfoId { get; set; }
        public string Place { get; set; }
        public string RegisterDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public string Remarks { get; set; }

        public PlaceInfoTable()
        {
            
        }
        public PlaceInfoTable(string Place, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.Place = Place;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }

        public PlaceInfoTable(int PlaceInfoId,string Place, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.PlaceInfoId = PlaceInfoId;
            this.Place = Place;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }
    }

}
