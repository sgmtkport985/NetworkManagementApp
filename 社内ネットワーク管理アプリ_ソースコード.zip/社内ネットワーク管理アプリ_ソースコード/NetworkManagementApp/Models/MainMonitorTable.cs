﻿
namespace NetworkManagementApp.Models
{
    public class MainMonitorTable
    {

        public string MacAddress { get; set; } = "";
        public string IpAddress { get; set; } = "";
        public string VendorName { get; set; } = "";
        public string Category { get; set; } = "";
        public string VLAN { get; set; } = "";
        public string HostName { get; set; } = "";
        public string Place { get; set; } = "";
        public string IsMacAddressMonitor { get; set; } = "";
        public string IsIpAddressMonitor { get; set; } = "";
        public string IsPDI { get; set; } = "";
        
        public MainMonitorTable()
        {
        
        }
    }
}
