﻿
namespace NetworkManagementApp.Models
{
    public class IpMonitorInfoTable : InfoTable
    {
        public int IpMonitorInfoId { get; set; }
        public string IPAddress { get; set; }
        public string RegisterDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public string Remarks { get; set; }

        public IpMonitorInfoTable()
        {

        }
        public IpMonitorInfoTable(string IPAddress, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.IPAddress = IPAddress;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }

        public IpMonitorInfoTable(int IpMonitorInfoId, string IPAddress, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.IpMonitorInfoId = IpMonitorInfoId;
            this.IPAddress = IPAddress;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }
    }
}
