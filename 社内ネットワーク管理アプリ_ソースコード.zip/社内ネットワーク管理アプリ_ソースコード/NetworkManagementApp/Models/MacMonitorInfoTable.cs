﻿
namespace NetworkManagementApp.Models
{
    public class MacMonitorInfoTable : InfoTable
    {
        public int MacMonitorInfoId { get; set; }
        public string MACAddress { get; set; }
        public string RegisterDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public string Remarks { get; set; }

        public MacMonitorInfoTable()
        {

        }

        public MacMonitorInfoTable(string MACAddress, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.MACAddress = MACAddress;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }

        public MacMonitorInfoTable(int MacMonitorInfoId, string MACAddress, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.MacMonitorInfoId = MacMonitorInfoId;
            this.MACAddress = MACAddress;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }
    }
}
