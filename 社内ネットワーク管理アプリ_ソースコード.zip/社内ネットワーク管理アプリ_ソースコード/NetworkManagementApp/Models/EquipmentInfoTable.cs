﻿
namespace NetworkManagementApp.Models
{
    public class EquipmentInfoTable : InfoTable
    {
        public int EquipmentInfoId { get; set; }
        public string MacAddress { get; set; }
        public string IpAddress { get; set; }
        public string HostName { get; set; }
        public string VendorName { get; set; }
        public string Category { get; set; }
        public string ModelNumber { get; set; }
        public string Place { get; set; }
        public string RegisterDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public string Remarks { get; set; }


        public EquipmentInfoTable()
        {

        }

        public EquipmentInfoTable(string MacAddress, string IpAddress, string HostName, string VendorName,string Category, string Place, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.MacAddress = MacAddress;
            this.IpAddress = IpAddress;
            this.HostName = HostName;
            this.VendorName = VendorName;
            this.Category = Category;
            this.Place = Place;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }

        public EquipmentInfoTable(int EquipmentInfoId, string MacAddress, string IpAddress, string HostName, string VendorName,string Place, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.EquipmentInfoId = EquipmentInfoId;
            this.MacAddress = MacAddress;
            this.IpAddress = IpAddress;
            this.HostName = HostName;
            this.VendorName = VendorName;
            this.Place = Place;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }

        public EquipmentInfoTable(int EquipmentInfoId, string MacAddress, string IpAddress, string HostName, string VendorName, string Category, string ModelNumber, string Place, string RegisterDateTime, string UpdateDateTime, string Remarks)
        {
            this.EquipmentInfoId = EquipmentInfoId;
            this.MacAddress = MacAddress;
            this.IpAddress = IpAddress;
            this.HostName = HostName;
            this.VendorName = VendorName;
            this.Category = Category;
            this.ModelNumber = ModelNumber;
            this.Place = Place;
            this.RegisterDateTime = RegisterDateTime;
            this.UpdateDateTime = UpdateDateTime;
            this.Remarks = Remarks;
        }
    }
}
