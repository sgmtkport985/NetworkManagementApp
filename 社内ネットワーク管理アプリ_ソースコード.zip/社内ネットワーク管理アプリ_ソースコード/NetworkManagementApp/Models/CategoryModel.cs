﻿using System.Collections.ObjectModel;

namespace NetworkManagementApp.Models
{
    public class CategoryModel
    {
        public static ObservableCollection<string>  Categorys { get; set; } = new ObservableCollection<string>()
        {
            "ＰＣ",
            "ＰＲ",
            "ＮＷ",
            "不明"
        };
    }
}
