﻿using System;
using System.Windows.Input;

namespace NetworkManagementApp.MVVM
{
    public class RelayCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        public Predicate<object> CanExecution { get; set; }
        public Action<object> Execution { get; set; }

        public RelayCommand(Action<object> execution, Predicate<object> canExecution)
        {
            Execution = execution;
            CanExecution = canExecution;
        }

        public bool CanExecute(object parameter)
        {
            return CanExecution(parameter);
        }

        public void Execute(object parameter)
        {
            Execution(parameter);
        }
    }
}
